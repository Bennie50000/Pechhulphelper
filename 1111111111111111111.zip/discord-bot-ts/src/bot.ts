/**
 * Start hier: npm run build && npm start  (of "npm run dev" tijdens ontwikkelen)
 *
 * Deze bot combineert functionaliteit van:
 * - Dyno         -> moderatie (kick/ban/mute/logs)
 * - Tickettool   -> ticket systeem (dropdown + formulier per type)
 * - Verjaardagenbot -> verjaardagen bijhouden + felicitaties
 * - Plus algemene commands (help, ping, info), speeltijd-tracking,
 *   uitgebreide server logs en aanpasbare embeds
 */
import { Client, GatewayIntentBits, Events, REST, Routes, Collection } from "discord.js";
import { DISCORD_TOKEN, CLIENT_ID } from "./config";
import { initDb } from "./database";
import { BotModule, SlashCommand } from "./types";

import generalModule from "./modules/general";
import moderationModule from "./modules/moderation";
import ticketsModule from "./modules/tickets";
import birthdaysModule from "./modules/birthdays";
import playtimeModule from "./modules/playtime";
import serverlogsModule from "./modules/serverlogs";
import embedbuilderModule from "./modules/embedbuilder";
import staffModule from "./modules/staff";
import quickrepliesModule from "./modules/quickreplies";
import schedulingModule from "./modules/scheduling";
import gamesModule from "./modules/games";

const MODULES: BotModule[] = [
  generalModule,
  moderationModule,
  ticketsModule,
  birthdaysModule,
  playtimeModule,
  serverlogsModule,
  embedbuilderModule,
  staffModule,
  quickrepliesModule,
  schedulingModule,
  gamesModule,
];

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers, // nodig voor moderatie/verjaardagen/ledeninfo/server logs
    GatewayIntentBits.GuildMessages, // nodig voor server logs (edit/delete)
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildPresences, // nodig voor speeltijd-tracking (/playtime)
    GatewayIntentBits.GuildModeration, // nodig voor ban/unban logs
    GatewayIntentBits.GuildVoiceStates, // nodig voor voicekanaal join/leave/wissel logs
    GatewayIntentBits.GuildInvites, // nodig voor uitnodiging aangemaakt/verwijderd logs
    GatewayIntentBits.GuildEmojisAndStickers, // nodig voor emoji logs
    GatewayIntentBits.GuildWebhooks, // nodig voor webhook logs
    GatewayIntentBits.AutoModerationConfiguration, // nodig voor AutoMod-regel logs
    GatewayIntentBits.AutoModerationExecution, // nodig voor AutoMod-actie logs
  ],
});

const commandHandlers = new Collection<string, SlashCommand>();

async function registerCommands(): Promise<void> {
  const commandsJson = [];
  for (const mod of MODULES) {
    for (const command of mod.commands) {
      commandHandlers.set(command.data.name, command);
      commandsJson.push(command.data.toJSON());
    }
  }

  const rest = new REST().setToken(DISCORD_TOKEN!);
  const data = (await rest.put(Routes.applicationCommands(CLIENT_ID!), { body: commandsJson })) as unknown[];
  console.log(`[INFO] ${data.length} slash commands geregistreerd.`);
}

client.once(Events.ClientReady, async (readyClient) => {
  console.log(`[INFO] Ingelogd als ${readyClient.user.tag} (ID: ${readyClient.user.id})`);

  await registerCommands();

  for (const mod of MODULES) {
    if (mod.onReady) {
      await mod.onReady(readyClient);
      console.log(`[INFO] Module '${mod.name}' gestart.`);
    }
  }

  readyClient.user.setActivity("/help voor commands");
});

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (interaction.isChatInputCommand()) {
      const command = commandHandlers.get(interaction.commandName);
      if (!command) return;
      await command.execute(interaction);
      return;
    }

    if (interaction.isButton()) {
      for (const mod of MODULES) {
        if (mod.handleButton && (await mod.handleButton(interaction))) return;
      }
      return;
    }

    if (interaction.isStringSelectMenu()) {
      for (const mod of MODULES) {
        if (mod.handleSelectMenu && (await mod.handleSelectMenu(interaction))) return;
      }
      return;
    }

    if (interaction.isUserSelectMenu()) {
      for (const mod of MODULES) {
        if (mod.handleUserSelectMenu && (await mod.handleUserSelectMenu(interaction))) return;
      }
      return;
    }

    if (interaction.isChannelSelectMenu()) {
      for (const mod of MODULES) {
        if (mod.handleChannelSelectMenu && (await mod.handleChannelSelectMenu(interaction))) return;
      }
      return;
    }

    if (interaction.isModalSubmit()) {
      for (const mod of MODULES) {
        if (mod.handleModalSubmit && (await mod.handleModalSubmit(interaction))) return;
      }
      return;
    }
  } catch (error) {
    console.error("[ERROR] Fout bij verwerken van interactie:", error);
    const errorMessage = "❌ Er ging iets mis bij het uitvoeren van dit command.";
    if (interaction.isRepliable()) {
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: errorMessage, ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: errorMessage, ephemeral: true }).catch(() => {});
      }
    }
  }
});

client.on(Events.MessageCreate, async (message) => {
  for (const mod of MODULES) {
    if (mod.handleMessage) {
      try {
        await mod.handleMessage(message);
      } catch (error) {
        console.error(`[ERROR] Fout in handleMessage van module '${mod.name}':`, error);
      }
    }
  }
});

async function main(): Promise<void> {
  initDb();
  await client.login(DISCORD_TOKEN);
}

main().catch((error) => {
  console.error("[FATAL]", error);
  process.exit(1);
});
