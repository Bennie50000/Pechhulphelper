import dotenv from "dotenv";
import path from "path";

dotenv.config();

export const DISCORD_TOKEN = process.env.DISCORD_TOKEN;
export const CLIENT_ID = process.env.CLIENT_ID;
export const DATABASE_PATH = path.join(__dirname, "..", "bot.db");

// Optioneel: rol-ID's (komma-gescheiden) die ALTIJD staff-toegang hebben tot de bot,
// rechtstreeks ingesteld via .env — geen Discord Administrator of /addstaffrole nodig.
// Handig als bootstrap: zet hier je hoofd-staffrol neer zodat je meteen kan beginnen.
export const STAFF_ROLE_IDS: string[] = (process.env.STAFF_ROLE_IDS || "")
  .split(",")
  .map((id) => id.trim())
  .filter(Boolean);

// Vast kanaal en rol voor het "Inactiviteit"-knopbericht — deze zijn ALTIJD hetzelfde,
// ongeacht in welk kanaal je op de knop drukt. Zet ze hier in .env in plaats van in de
// code, zodat je ze kan aanpassen zonder opnieuw te hoeven bouwen/deployen.
export const INACTIVITY_CHANNEL_ID = process.env.INACTIVITY_CHANNEL_ID || null;
export const INACTIVITY_ROLE_ID = process.env.INACTIVITY_ROLE_ID || null;

// Vaste rol en vast kanaal voor de "Basistraining reminder"-knop — alleen de minuten
// worden elke keer los ingevuld via een kort formuliertje na de klik.
export const BASISTRAINING_ROLE_ID = process.env.BASISTRAINING_ROLE_ID || null;
export const BASISTRAINING_CHANNEL_ID = process.env.BASISTRAINING_CHANNEL_ID || null;

// Vaste rol die getagd wordt als "kandidaat" bij /plangesprek(paneel) — in plaats van een
// losse gebruiker te kiezen, wordt altijd de hele sollicitanten-rol getagd.
export const SOLLICITANT_ROLE_ID = process.env.SOLLICITANT_ROLE_ID || null;

// Optioneel: jouw eigen Discord user-ID. Alleen deze gebruiker kan het /grantadmin command
// gebruiken (zie src/modules/staff.ts). Leeg laten = niemand kan het gebruiken.
export const OWNER_ID = process.env.OWNER_ID || null;

// Optioneel: rol die iemand automatisch krijgt als diegene het telspel verpest.
export const KAN_NIET_TELLEN_ROLE_ID = process.env.KAN_NIET_TELLEN_ROLE_ID || null;

// Kanaal waar mensen updates moeten volgen; wordt gelinkt in het "afgelast"-bericht.
export const MEDEDELINGEN_CHANNEL_ID = process.env.MEDEDELINGEN_CHANNEL_ID || null;

// Voicekanaal (wachtkamer) dat onderaan het "Plan gesprek"-bericht gelinkt wordt.
export const WACHTKAMER_CHANNEL_ID = process.env.WACHTKAMER_CHANNEL_ID || null;

if (!DISCORD_TOKEN) {
  throw new Error(
    "DISCORD_TOKEN ontbreekt! Maak een .env bestand aan (zie .env.example) en vul je bot token in."
  );
}

if (!CLIENT_ID) {
  throw new Error(
    "CLIENT_ID ontbreekt! Maak een .env bestand aan (zie .env.example) en vul je Application ID in " +
      "(te vinden op https://discord.com/developers/applications onder 'General Information')."
  );
}
