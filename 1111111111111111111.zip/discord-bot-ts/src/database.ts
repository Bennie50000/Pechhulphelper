import Database from "better-sqlite3";
import { DATABASE_PATH } from "./config";

export const db = new Database(DATABASE_PATH);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

export function initDb(): void {
  db.exec(`
    -- Moderatie: instellingen per server
    CREATE TABLE IF NOT EXISTS mod_config (
      guild_id TEXT PRIMARY KEY,
      log_channel_id TEXT
    );

    -- Tickets: algemene instellingen per server
    CREATE TABLE IF NOT EXISTS ticket_config (
      guild_id TEXT PRIMARY KEY,
      log_channel_id TEXT,
      archive_category_id TEXT
    );

    -- Tickets: type-opties voor de dropdown, elk met eigen categorie + supportrol
    CREATE TABLE IF NOT EXISTS ticket_types (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL,
      label TEXT NOT NULL,
      emoji TEXT,
      description TEXT,
      category_id TEXT NOT NULL,
      support_role_id TEXT NOT NULL
    );

    -- Tickets: vragen die getoond worden in een formulier (modal) voordat het ticket
    -- wordt aangemaakt, per ticket-type. Max. 5 per type (Discord-limiet op een modal).
    CREATE TABLE IF NOT EXISTS ticket_questions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ticket_type_id INTEGER NOT NULL,
      question TEXT NOT NULL,
      style TEXT DEFAULT 'short',
      required INTEGER DEFAULT 1,
      position INTEGER NOT NULL,
      FOREIGN KEY (ticket_type_id) REFERENCES ticket_types(id) ON DELETE CASCADE
    );

    -- Tickets: actieve/afgesloten tickets
    CREATE TABLE IF NOT EXISTS tickets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL,
      channel_id TEXT,
      user_id TEXT NOT NULL,
      ticket_type_label TEXT,
      status TEXT DEFAULT 'open',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      closed_at TEXT
    );

    -- Verjaardagen
    CREATE TABLE IF NOT EXISTS birthdays (
      guild_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      day INTEGER NOT NULL,
      month INTEGER NOT NULL,
      year INTEGER,
      PRIMARY KEY (guild_id, user_id)
    );

    -- Verjaardagen: instellingen per server
    CREATE TABLE IF NOT EXISTS birthday_config (
      guild_id TEXT PRIMARY KEY,
      channel_id TEXT,
      role_id TEXT,
      last_announced_date TEXT
    );

    -- Speeltijd: totaal aantal seconden per gebruiker per game (via Discord-activiteit/rich presence)
    CREATE TABLE IF NOT EXISTS game_playtime (
      guild_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      game_name TEXT NOT NULL,
      seconds INTEGER DEFAULT 0,
      PRIMARY KEY (guild_id, user_id, game_name)
    );

    -- Uitgebreide server logs: instellingen per server
    CREATE TABLE IF NOT EXISTS server_log_config (
      guild_id TEXT PRIMARY KEY,
      channel_id TEXT
    );

    -- Embed-editor: welke rol (ID) berichten mag bewerken via de "Bewerken"-knop
    CREATE TABLE IF NOT EXISTS embed_editor_config (
      guild_id TEXT PRIMARY KEY,
      role_id TEXT
    );

    -- Staff-rollen: rollen die bot-configuratiecommands mogen gebruiken, los van Discord's
    -- eigen "Administrator"-permissie. Leden met Administrator mogen dit altijd, ook zonder
    -- hier expliciet toegevoegd te zijn.
    CREATE TABLE IF NOT EXISTS staff_roles (
      guild_id TEXT NOT NULL,
      role_id TEXT NOT NULL,
      PRIMARY KEY (guild_id, role_id)
    );

    -- Snelle-antwoord-knoppen: label + kant-en-klaar bericht, geplaatst als knoppenpaneel
    CREATE TABLE IF NOT EXISTS quick_reply_buttons (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL,
      label TEXT NOT NULL,
      message_content TEXT NOT NULL,
      emoji TEXT,
      style TEXT DEFAULT 'primary'
    );

    -- Minigame: telspel (counting) — 1 actief spel per kanaal
    CREATE TABLE IF NOT EXISTS counting_game (
      guild_id TEXT NOT NULL,
      channel_id TEXT NOT NULL,
      current_count INTEGER DEFAULT 0,
      last_user_id TEXT,
      high_score INTEGER DEFAULT 0,
      PRIMARY KEY (guild_id, channel_id)
    );

    -- Minigame: galgje (hangman) — 1 actief spel per kanaal
    CREATE TABLE IF NOT EXISTS hangman_game (
      guild_id TEXT NOT NULL,
      channel_id TEXT NOT NULL,
      word TEXT NOT NULL,
      guessed_letters TEXT DEFAULT '',
      wrong_count INTEGER DEFAULT 0,
      started_by TEXT,
      PRIMARY KEY (guild_id, channel_id)
    );

    -- Minigame: getal raden — 1 actief spel per kanaal
    CREATE TABLE IF NOT EXISTS guessing_game (
      guild_id TEXT NOT NULL,
      channel_id TEXT NOT NULL,
      target_number INTEGER NOT NULL,
      min_number INTEGER NOT NULL,
      max_number INTEGER NOT NULL,
      attempts INTEGER DEFAULT 0,
      started_by TEXT,
      PRIMARY KEY (guild_id, channel_id)
    );

    -- Minigames: vast kanaal per spel-type, 1x ingesteld (game_type: 'telspel'/'galgje'/'raadgetal')
    CREATE TABLE IF NOT EXISTS game_channels (
      guild_id TEXT NOT NULL,
      game_type TEXT NOT NULL,
      channel_id TEXT NOT NULL,
      PRIMARY KEY (guild_id, game_type)
    );
  `);

  // Kleine migratie voor bestaande databases die al draaiden vóór deze kolom bestond.
  try {
    db.exec("ALTER TABLE ticket_config ADD COLUMN archive_category_id TEXT");
  } catch {
    // kolom bestaat al
  }
}
