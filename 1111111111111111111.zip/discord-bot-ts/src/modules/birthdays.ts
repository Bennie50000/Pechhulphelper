import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType, Client, TextChannel } from "discord.js";
import { BotModule } from "../types";
import { requireStaff } from "../permissions";
import { db } from "../database";

const MAANDEN_NL = [
  "januari", "februari", "maart", "april", "mei", "juni",
  "juli", "augustus", "september", "oktober", "november", "december",
];

function isValidDate(day: number, month: number): boolean {
  const d = new Date(2000, month - 1, day); // 2000 = schrikkeljaar, voor 29 februari
  return d.getMonth() === month - 1 && d.getDate() === day;
}

async function checkBirthdays(client: Client): Promise<void> {
  const today = new Date();
  const todayStr = today.toISOString().slice(0, 10);

  const configs = db.prepare("SELECT * FROM birthday_config").all() as any[];

  for (const cfg of configs) {
    if (cfg.last_announced_date === todayStr) continue; // al gedaan vandaag voor deze server
    if (!cfg.channel_id) continue;

    const guild = client.guilds.cache.get(cfg.guild_id);
    if (!guild) continue;
    const channel = (await guild.channels.fetch(cfg.channel_id).catch(() => null)) as TextChannel | null;
    if (!channel) continue;

    const jarigen = db
      .prepare("SELECT * FROM birthdays WHERE guild_id = ? AND day = ? AND month = ?")
      .all(cfg.guild_id, today.getDate(), today.getMonth() + 1) as any[];

    for (const jarige of jarigen) {
      const member = await guild.members.fetch(jarige.user_id).catch(() => null);
      if (!member) continue;

      let leeftijdTekst = "";
      if (jarige.year) {
        const age = today.getFullYear() - jarige.year;
        leeftijdTekst = ` en wordt vandaag **${age} jaar**`;
      }
      await channel.send(`🎉🎂 Gefeliciteerd ${member}! Je bent vandaag jarig${leeftijdTekst}! 🎈`).catch(() => {});

      if (cfg.role_id) {
        const role = guild.roles.cache.get(cfg.role_id);
        if (role) await member.roles.add(role, "Jarig vandaag").catch(() => {});
      }
    }

    db.prepare("UPDATE birthday_config SET last_announced_date = ? WHERE guild_id = ?").run(todayStr, cfg.guild_id);
  }
}

const birthdaysModule: BotModule = {
  name: "birthdays",
  onReady: (client) => {
    // Elke 30 minuten checken, net als de Python-versie
    checkBirthdays(client);
    setInterval(() => checkBirthdays(client), 30 * 60 * 1000);
  },
  commands: [
    {
      data: new SlashCommandBuilder()
        .setName("setbirthday")
        .setDescription("Stel je verjaardag in.")
        .addIntegerOption((opt) => opt.setName("day").setDescription("Dag van de maand (1-31)").setMinValue(1).setMaxValue(31).setRequired(true))
        .addIntegerOption((opt) => opt.setName("month").setDescription("Maand (1-12)").setMinValue(1).setMaxValue(12).setRequired(true))
        .addIntegerOption((opt) => opt.setName("year").setDescription("Geboortejaar (optioneel)")),
      execute: async (interaction) => {
        if (!(await requireStaff(interaction))) return;
        const day = interaction.options.getInteger("day", true);
        const month = interaction.options.getInteger("month", true);
        const year = interaction.options.getInteger("year");

        if (!isValidDate(day, month)) {
          await interaction.reply({ content: "❌ Deze datum bestaat niet.", ephemeral: true });
          return;
        }

        db.prepare(
          `INSERT INTO birthdays (guild_id, user_id, day, month, year) VALUES (?, ?, ?, ?, ?)
           ON CONFLICT(guild_id, user_id) DO UPDATE SET day = excluded.day, month = excluded.month, year = excluded.year`
        ).run(interaction.guildId, interaction.user.id, day, month, year);

        await interaction.reply({
          content: `🎂 Je verjaardag is ingesteld op **${day} ${MAANDEN_NL[month - 1]}**${year ? ` ${year}` : ""}!`,
          ephemeral: true,
        });
      },
    },
    {
      data: new SlashCommandBuilder().setName("removebirthday").setDescription("Verwijder je opgeslagen verjaardag."),
      execute: async (interaction) => {
        db.prepare("DELETE FROM birthdays WHERE guild_id = ? AND user_id = ?").run(interaction.guildId, interaction.user.id);
        await interaction.reply({ content: "🗑️ Je verjaardag is verwijderd.", ephemeral: true });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("birthday")
        .setDescription("Bekijk de verjaardag van een lid.")
        .addUserOption((opt) => opt.setName("member").setDescription("Lid om te bekijken (standaard: jijzelf)")),
      execute: async (interaction) => {
        const target = interaction.options.getUser("member") ?? interaction.user;
        const row = db.prepare("SELECT * FROM birthdays WHERE guild_id = ? AND user_id = ?").get(interaction.guildId, target.id) as any;
        if (!row) {
          await interaction.reply(`**${target.username}** heeft geen verjaardag ingesteld.`);
          return;
        }
        let text = `🎂 **${target.username}** is jarig op **${row.day} ${MAANDEN_NL[row.month - 1]}**`;
        if (row.year) {
          const age = new Date().getFullYear() - row.year;
          text += ` (wordt ${age} jaar)`;
        }
        await interaction.reply(text);
      },
    },
    {
      data: new SlashCommandBuilder().setName("birthdaylist").setDescription("Toon de eerstvolgende verjaardagen op deze server."),
      execute: async (interaction) => {
        const rows = db.prepare("SELECT * FROM birthdays WHERE guild_id = ?").all(interaction.guildId) as any[];
        if (rows.length === 0) {
          await interaction.reply("Nog niemand heeft een verjaardag ingesteld.");
          return;
        }

        const today = new Date();
        const daysUntil = (row: any): number => {
          let thisYear = new Date(today.getFullYear(), row.month - 1, row.day);
          if (thisYear < today) thisYear = new Date(today.getFullYear() + 1, row.month - 1, row.day);
          return Math.round((thisYear.getTime() - today.getTime()) / 86400000);
        };

        const sorted = [...rows].sort((a, b) => daysUntil(a) - daysUntil(b)).slice(0, 15);

        const embed = new EmbedBuilder().setTitle("🎂 Eerstvolgende verjaardagen").setColor(0xeb459e);
        for (const row of sorted) {
          const member = interaction.guild!.members.cache.get(row.user_id);
          const name = member ? member.displayName : `Onbekend lid (${row.user_id})`;
          embed.addFields({ name, value: `${row.day} ${MAANDEN_NL[row.month - 1]}`, inline: true });
        }
        await interaction.reply({ embeds: [embed] });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("setbirthdaychannel")
        .setDescription("Stel het kanaal in voor verjaardagsfelicitaties.")
        .addChannelOption((opt) =>
          opt.setName("channel").setDescription("Kanaal voor felicitaties").addChannelTypes(ChannelType.GuildText).setRequired(true)
        )
        .addRoleOption((opt) => opt.setName("role").setDescription("Optionele 'jarige' rol")),
      execute: async (interaction) => {
        const channel = interaction.options.getChannel("channel", true);
        const role = interaction.options.getRole("role");
        db.prepare(
          `INSERT INTO birthday_config (guild_id, channel_id, role_id) VALUES (?, ?, ?)
           ON CONFLICT(guild_id) DO UPDATE SET channel_id = excluded.channel_id, role_id = excluded.role_id`
        ).run(interaction.guildId, channel.id, role?.id ?? null);
        await interaction.reply({ content: `✅ Verjaardagskanaal ingesteld op <#${channel.id}>.`, ephemeral: true });
      },
    },
  ],
};

export default birthdaysModule;
