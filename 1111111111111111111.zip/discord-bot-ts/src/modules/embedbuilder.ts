import {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ButtonInteraction,
  ModalSubmitInteraction,
  TextChannel,
} from "discord.js";
import { BotModule } from "../types";
import { requireStaff, isStaff } from "../permissions";
import { db } from "../database";

const EDIT_BUTTON_ID = "embed_edit_button";
const EDIT_MODAL_PREFIX = "embed_edit_modal_";
const DEFAULT_COLOR = 0x5865f2;

function buildEditButtonRow(): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(EDIT_BUTTON_ID).setLabel("Bewerken").setStyle(ButtonStyle.Secondary).setEmoji("✏️")
  );
}

function getEditRoleId(guildId: string): string | null {
  const row = db.prepare("SELECT role_id FROM embed_editor_config WHERE guild_id = ?").get(guildId) as any;
  return row?.role_id ?? null;
}

/** Zet een hex-kleurcode ("#5865F2", "5865F2" of "0x5865F2") om naar een getal. Geeft null terug bij een ongeldige invoer. */
function parseColor(input: string | null): number | null {
  if (!input) return null;
  const cleaned = input.trim().replace(/^#/, "").replace(/^0x/i, "");
  if (!/^[0-9a-fA-F]{6}$/.test(cleaned)) return null;
  return parseInt(cleaned, 16);
}

async function handleButton(interaction: ButtonInteraction): Promise<boolean> {
  if (interaction.customId !== EDIT_BUTTON_ID) return false;

  const editRoleId = getEditRoleId(interaction.guildId!);
  const member = interaction.member as any;
  const isAdmin = isStaff(interaction);
  const hasEditRole = editRoleId ? member?.roles?.cache?.has?.(editRoleId) : false;

  if (!editRoleId) {
    await interaction.reply({ content: "❌ Er is nog geen bewerk-rol ingesteld. Gebruik `/setembededitrole`.", ephemeral: true });
    return true;
  }
  if (!isAdmin && !hasEditRole) {
    await interaction.reply({ content: "❌ Je hebt geen rechten om dit bericht te bewerken.", ephemeral: true });
    return true;
  }

  const existingEmbed = interaction.message.embeds[0];
  const modal = new ModalBuilder()
    .setCustomId(`${EDIT_MODAL_PREFIX}${interaction.message.id}`)
    .setTitle("Bericht bewerken");

  const titleInput = new TextInputBuilder()
    .setCustomId("title")
    .setLabel("Titel")
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setValue(existingEmbed?.title ?? "");

  const descriptionInput = new TextInputBuilder()
    .setCustomId("description")
    .setLabel("Beschrijving")
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true)
    .setValue(existingEmbed?.description ?? "");

  const imageInput = new TextInputBuilder()
    .setCustomId("image_url")
    .setLabel("Afbeelding-URL")
    .setStyle(TextInputStyle.Short)
    .setRequired(false)
    .setValue(existingEmbed?.image?.url ?? "");

  const footerTextInput = new TextInputBuilder()
    .setCustomId("footer_text")
    .setLabel("Footertekst")
    .setStyle(TextInputStyle.Short)
    .setRequired(false)
    .setValue(existingEmbed?.footer?.text ?? "");

  const footerImageInput = new TextInputBuilder()
    .setCustomId("footer_image_url")
    .setLabel("Footer-afbeelding-URL")
    .setStyle(TextInputStyle.Short)
    .setRequired(false)
    .setValue(existingEmbed?.footer?.iconURL ?? "");

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(titleInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(descriptionInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(imageInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(footerTextInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(footerImageInput)
  );

  await interaction.showModal(modal);
  return true;
}

async function handleModalSubmit(interaction: ModalSubmitInteraction): Promise<boolean> {
  if (!interaction.customId.startsWith(EDIT_MODAL_PREFIX)) return false;

  const messageId = interaction.customId.slice(EDIT_MODAL_PREFIX.length);
  const title = interaction.fields.getTextInputValue("title");
  const description = interaction.fields.getTextInputValue("description");
  const imageUrl = interaction.fields.getTextInputValue("image_url");
  const footerText = interaction.fields.getTextInputValue("footer_text");
  const footerImageUrl = interaction.fields.getTextInputValue("footer_image_url");

  try {
    const channel = interaction.channel as TextChannel;
    const message = await channel.messages.fetch(messageId);
    // Kleur wijzig je niet via dit formulier (dat zit al vol met 5 velden, het Discord-max) —
    // de bestaande kleur van het bericht blijft dus gewoon staan.
    const existingColor = message.embeds[0]?.color ?? DEFAULT_COLOR;

    const embed = new EmbedBuilder().setTitle(title).setDescription(description).setColor(existingColor);
    if (imageUrl) embed.setImage(imageUrl);
    if (footerText) embed.setFooter({ text: footerText, iconURL: footerImageUrl || undefined });

    await message.edit({ embeds: [embed] });
    await interaction.reply({ content: "✅ Bericht bijgewerkt.", ephemeral: true });
  } catch {
    await interaction.reply({ content: "❌ Kon het bericht niet meer vinden/bewerken (mogelijk verwijderd).", ephemeral: true });
  }
  return true;
}

const embedbuilderModule: BotModule = {
  name: "embedbuilder",
  handleButton,
  handleModalSubmit,
  commands: [
    {
      data: new SlashCommandBuilder()
        .setName("setembededitrole")
        .setDescription("Stel in welke rol berichten mag bewerken via de 'Bewerken'-knop.")
        .addRoleOption((opt) => opt.setName("role").setDescription("De rol (kies via de lijst)"))
        .addStringOption((opt) => opt.setName("role_id").setDescription("Of vul hier direct een rol-ID in")),
      execute: async (interaction) => {
        if (!(await requireStaff(interaction))) return;
        const role = interaction.options.getRole("role");
        const roleIdInput = interaction.options.getString("role_id");
        const roleId = role?.id ?? roleIdInput;

        if (!roleId) {
          await interaction.reply({ content: "❌ Geef óf `role` óf `role_id` op.", ephemeral: true });
          return;
        }
        if (!/^\d{15,25}$/.test(roleId)) {
          await interaction.reply({ content: "❌ Dat lijkt geen geldig rol-ID.", ephemeral: true });
          return;
        }

        db.prepare(
          `INSERT INTO embed_editor_config (guild_id, role_id) VALUES (?, ?)
           ON CONFLICT(guild_id) DO UPDATE SET role_id = excluded.role_id`
        ).run(interaction.guildId, roleId);
        await interaction.reply({ content: `✅ Alleen leden met <@&${roleId}> (of Administrator) kunnen voortaan op 'Bewerken' klikken.`, ephemeral: true });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("createembed")
        .setDescription("Plaats een aanpasbaar bericht (embed) met een 'Bewerken'-knop.")
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
        .addStringOption((opt) => opt.setName("title").setDescription("Titel").setRequired(true))
        .addStringOption((opt) => opt.setName("description").setDescription("Beschrijving").setRequired(true))
        .addStringOption((opt) => opt.setName("color").setDescription("Kleur van de balk links, hex-code (bv. #FF5733 of FF5733)"))
        .addStringOption((opt) => opt.setName("image_url").setDescription("Afbeelding-URL (optioneel)"))
        .addStringOption((opt) => opt.setName("footer_text").setDescription("Footertekst (optioneel)"))
        .addStringOption((opt) => opt.setName("footer_image_url").setDescription("Footer-afbeelding-URL (optioneel)")),
      execute: async (interaction) => {
        const title = interaction.options.getString("title", true);
        const description = interaction.options.getString("description", true);
        const colorInput = interaction.options.getString("color");
        const imageUrl = interaction.options.getString("image_url");
        const footerText = interaction.options.getString("footer_text");
        const footerImageUrl = interaction.options.getString("footer_image_url");

        const parsedColor = parseColor(colorInput);
        if (colorInput && parsedColor === null) {
          await interaction.reply({
            content: "❌ Ongeldige kleur. Gebruik een hex-code zoals `#FF5733` of `FF5733` (6 tekens, 0-9 en A-F).",
            ephemeral: true,
          });
          return;
        }

        const embed = new EmbedBuilder().setTitle(title).setDescription(description).setColor(parsedColor ?? DEFAULT_COLOR);
        if (imageUrl) embed.setImage(imageUrl);
        if (footerText) embed.setFooter({ text: footerText, iconURL: footerImageUrl || undefined });

        const channel = interaction.channel as TextChannel;
        await channel.send({ embeds: [embed], components: [buildEditButtonRow()] });
        await interaction.reply({ content: "✅ Bericht geplaatst.", ephemeral: true });
      },
    },
  ],
};

export default embedbuilderModule;
