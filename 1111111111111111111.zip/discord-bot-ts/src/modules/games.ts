import { SlashCommandBuilder, EmbedBuilder, ChannelType, TextChannel, Message } from "discord.js";
import { BotModule } from "../types";
import { requireStaff } from "../permissions";
import { db } from "../database";
import { KAN_NIET_TELLEN_ROLE_ID } from "../config";

// ---------- Woordenlijst voor galgje ----------
const HANGMAN_WORDS = [
  "discord", "computer", "toetsenbord", "programmeren", "vakantie", "olifant", "regenboog",
  "sleutelbos", "voetbal", "muziek", "schoolplein", "vlinder", "brandweer", "ziekenhuis",
  "restaurant", "fietsband", "supermarkt", "kangoeroe", "paraplu", "sneeuwpop",
];

const HANGMAN_STAGES = [
  "```\n  +---+\n      |\n      |\n      |\n     ===```",
  "```\n  +---+\n  O   |\n      |\n      |\n     ===```",
  "```\n  +---+\n  O   |\n  |   |\n      |\n     ===```",
  "```\n  +---+\n  O   |\n /|   |\n      |\n     ===```",
  "```\n  +---+\n  O   |\n /|\\  |\n      |\n     ===```",
  "```\n  +---+\n  O   |\n /|\\  |\n /    |\n     ===```",
  "```\n  +---+\n  O   |\n /|\\  |\n / \\  |\n     ===```",
];

// ---------- Inspiratie/motivatie-quotes ----------
const QUOTES: Array<{ text: string; author: string }> = [
  { text: "The only way to do great work is to love what you do.", author: "Steve Jobs" },
  { text: "Success is not final, failure is not fatal: it is the courage to continue that counts.", author: "Winston Churchill" },
  { text: "Believe you can and you're halfway there.", author: "Theodore Roosevelt" },
  { text: "It always seems impossible until it's done.", author: "Nelson Mandela" },
  { text: "The future belongs to those who believe in the beauty of their dreams.", author: "Eleanor Roosevelt" },
  { text: "Don't watch the clock; do what it does. Keep going.", author: "Sam Levenson" },
  { text: "The best way to predict the future is to create it.", author: "Peter Drucker" },
  { text: "Life is 10% what happens to us and 90% how we react to it.", author: "Charles R. Swindoll" },
  { text: "You miss 100% of the shots you don't take.", author: "Wayne Gretzky" },
  { text: "Whether you think you can or you think you can't, you're right.", author: "Henry Ford" },
  { text: "The only limit to our realization of tomorrow is our doubts of today.", author: "Franklin D. Roosevelt" },
  { text: "Do what you can, with what you have, where you are.", author: "Theodore Roosevelt" },
  { text: "Hardships often prepare ordinary people for an extraordinary destiny.", author: "C.S. Lewis" },
  { text: "It does not matter how slowly you go as long as you do not stop.", author: "Confucius" },
  { text: "Everything you've ever wanted is on the other side of fear.", author: "George Addair" },
  { text: "Success usually comes to those who are too busy to be looking for it.", author: "Henry David Thoreau" },
  { text: "The way to get started is to quit talking and begin doing.", author: "Walt Disney" },
  { text: "Don't be afraid to give up the good to go for the great.", author: "John D. Rockefeller" },
  { text: "I find that the harder I work, the more luck I seem to have.", author: "Thomas Jefferson" },
  { text: "Opportunities don't happen, you create them.", author: "Chris Grosser" },
  { text: "The secret of getting ahead is getting started.", author: "Mark Twain" },
  { text: "Fall seven times, stand up eight.", author: "Japans gezegde" },
  { text: "Twintig jaar vanaf nu zul je meer teleurgesteld zijn door de dingen die je niet deed dan door de dingen die je wel deed.", author: "Mark Twain" },
  { text: "Geluk is niet iets kant-en-klaars. Het komt voort uit je eigen daden.", author: "Dalai Lama" },
  { text: "Val niet stil te staan bij het verleden, droom niet te veel over de toekomst, richt je geest op het huidige moment.", author: "Boeddha" },
];

function getCountingGame(guildId: string, channelId: string): any {
  return db.prepare("SELECT * FROM counting_game WHERE guild_id = ? AND channel_id = ?").get(guildId, channelId);
}

function getHangmanGame(guildId: string, channelId: string): any {
  return db.prepare("SELECT * FROM hangman_game WHERE guild_id = ? AND channel_id = ?").get(guildId, channelId);
}

function getGuessingGame(guildId: string, channelId: string): any {
  return db.prepare("SELECT * FROM guessing_game WHERE guild_id = ? AND channel_id = ?").get(guildId, channelId);
}

function getGameChannelId(guildId: string, gameType: string): string | null {
  const row = db.prepare("SELECT channel_id FROM game_channels WHERE guild_id = ? AND game_type = ?").get(guildId, gameType) as any;
  return row?.channel_id ?? null;
}

function hangmanDisplay(word: string, guessedLetters: string): string {
  return word
    .split("")
    .map((letter) => (guessedLetters.includes(letter.toLowerCase()) ? letter : "＿"))
    .join(" ");
}

async function sendHangmanState(channel: TextChannel, game: any, extraNote?: string): Promise<void> {
  const display = hangmanDisplay(game.word, game.guessed_letters);
  const embed = new EmbedBuilder()
    .setTitle("🎪 Galgje")
    .setColor(0x5865f2)
    .setDescription(
      `${HANGMAN_STAGES[Math.min(game.wrong_count, HANGMAN_STAGES.length - 1)]}\n\n` +
        `**Woord:** ${display}\n` +
        `**Foute letters:** ${game.guessed_letters.split("").filter((l: string) => !game.word.toLowerCase().includes(l)).join(", ") || "geen"}\n` +
        `**Fouten:** ${game.wrong_count}/6\n\n` +
        "Typ gewoon een letter in dit kanaal om te raden!"
    );
  if (extraNote) embed.setFooter({ text: extraNote });
  await channel.send({ embeds: [embed] });
}

async function handleMessage(message: Message): Promise<void> {
  if (message.author.bot || !message.guildId) return;
  const guildId = message.guildId;
  const channelId = message.channelId;
  const content = message.content.trim();

  // ---- Telspel ----
  const countingGame = getCountingGame(guildId, channelId);
  if (countingGame) {
    const expected = countingGame.current_count + 1;
    const isNumber = /^\d+$/.test(content);

    if (isNumber && Number(content) === expected && message.author.id !== countingGame.last_user_id) {
      const newHighScore = Math.max(countingGame.high_score, expected);
      db.prepare("UPDATE counting_game SET current_count = ?, last_user_id = ?, high_score = ? WHERE guild_id = ? AND channel_id = ?").run(
        expected, message.author.id, newHighScore, guildId, channelId
      );
      await message.react("✅").catch(() => {});
    } else if (isNumber) {
      db.prepare("UPDATE counting_game SET current_count = 0, last_user_id = NULL WHERE guild_id = ? AND channel_id = ?").run(guildId, channelId);
      await message.react("❌").catch(() => {});
      const reason = message.author.id === countingGame.last_user_id ? "je mag niet 2x achter elkaar tellen" : `het volgende getal moest **${expected}** zijn`;

      // "Kan niet tellen"-rol toekennen aan degene die het verpest heeft
      let roleNote = "";
      if (KAN_NIET_TELLEN_ROLE_ID && message.member) {
        const role = message.guild?.roles.cache.get(KAN_NIET_TELLEN_ROLE_ID);
        if (role) {
          try {
            await message.member.roles.add(role, "Telspel verpest");
            roleNote = ` Je krijgt hiervoor de rol **${role.name}** 😄`;
          } catch {
            // Bot mist rechten of rol staat te hoog — stil overslaan, spel gaat gewoon door
          }
        }
      }

      await (message.channel as TextChannel).send(
        `💥 **${message.author.username}** heeft het telspel verpest (${reason})! We beginnen weer bij **1**. Record dit potje: **${countingGame.high_score}**.${roleNote}`
      );
    }
    return;
  }

  // ---- Galgje ----
  const hangmanGame = getHangmanGame(guildId, channelId);
  if (hangmanGame && content.length === 1 && /^[a-zA-Z]$/.test(content)) {
    const letter = content.toLowerCase();
    if (hangmanGame.guessed_letters.includes(letter)) return;

    const guessedLetters = hangmanGame.guessed_letters + letter;
    const isCorrect = hangmanGame.word.toLowerCase().includes(letter);
    const wrongCount = hangmanGame.wrong_count + (isCorrect ? 0 : 1);

    db.prepare("UPDATE hangman_game SET guessed_letters = ?, wrong_count = ? WHERE guild_id = ? AND channel_id = ?").run(
      guessedLetters, wrongCount, guildId, channelId
    );

    const wordLetters = new Set<string>(hangmanGame.word.toLowerCase().split(""));
    const guessedSet = new Set(guessedLetters.split(""));
    const won = [...wordLetters].every((l) => guessedSet.has(l));
    const lost = wrongCount >= 6;
    const updatedGame = { ...hangmanGame, guessed_letters: guessedLetters, wrong_count: wrongCount };

    if (won) {
      db.prepare("DELETE FROM hangman_game WHERE guild_id = ? AND channel_id = ?").run(guildId, channelId);
      await sendHangmanState(message.channel as TextChannel, updatedGame, "🎉 Gewonnen! Gebruik /galgje start om opnieuw te spelen.");
    } else if (lost) {
      db.prepare("DELETE FROM hangman_game WHERE guild_id = ? AND channel_id = ?").run(guildId, channelId);
      await (message.channel as TextChannel).send(
        `💀 Verloren! Het woord was: **${hangmanGame.word}**. Gebruik \`/galgje start\` om opnieuw te spelen.`
      );
    } else {
      await sendHangmanState(message.channel as TextChannel, updatedGame);
    }
    return;
  }

  // ---- Getal raden ----
  const guessingGame = getGuessingGame(guildId, channelId);
  if (guessingGame && /^-?\d+$/.test(content)) {
    const guess = Number(content);
    const attempts = guessingGame.attempts + 1;

    if (guess === guessingGame.target_number) {
      db.prepare("DELETE FROM guessing_game WHERE guild_id = ? AND channel_id = ?").run(guildId, channelId);
      await message.reply(`🎉 Juist! Het getal was **${guessingGame.target_number}**. Je deed er **${attempts}** poging(en) over!`);
    } else {
      db.prepare("UPDATE guessing_game SET attempts = ? WHERE guild_id = ? AND channel_id = ?").run(attempts, guildId, channelId);
      await message.react(guess < guessingGame.target_number ? "📈" : "📉").catch(() => {});
    }
  }
}

const gamesModule: BotModule = {
  name: "games",
  handleMessage,
  commands: [
    {
      data: new SlashCommandBuilder()
        .setName("setspelkanaal")
        .setDescription("Stel het vaste kanaal in voor een minigame (1x instellen, daarna start het spel daar altijd).")
        .addStringOption((opt) =>
          opt
            .setName("spel")
            .setDescription("Welke minigame")
            .setRequired(true)
            .addChoices({ name: "Telspel", value: "telspel" }, { name: "Galgje", value: "galgje" }, { name: "Raad het getal", value: "raadgetal" })
        )
        .addChannelOption((opt) => opt.setName("kanaal").setDescription("Het kanaal voor dit spel").addChannelTypes(ChannelType.GuildText).setRequired(true)),
      execute: async (interaction) => {
        if (!(await requireStaff(interaction))) return;
        const spel = interaction.options.getString("spel", true);
        const kanaal = interaction.options.getChannel("kanaal", true);

        db.prepare(
          `INSERT INTO game_channels (guild_id, game_type, channel_id) VALUES (?, ?, ?)
           ON CONFLICT(guild_id, game_type) DO UPDATE SET channel_id = excluded.channel_id`
        ).run(interaction.guildId, spel, kanaal.id);

        await interaction.reply({ content: `✅ Kanaal voor **${spel}** ingesteld op <#${kanaal.id}>.`, ephemeral: true });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("telspel")
        .setDescription("Start of stop het telspel in dit kanaal.")
        .addStringOption((opt) =>
          opt.setName("actie").setDescription("Starten of stoppen").setRequired(true).addChoices({ name: "Start", value: "start" }, { name: "Stop", value: "stop" })
        ),
      execute: async (interaction) => {
        if (!(await requireStaff(interaction))) return;
        const actie = interaction.options.getString("actie", true);

        const channelId = getGameChannelId(interaction.guildId!, "telspel");
        if (!channelId) {
          await interaction.reply({ content: "❌ Stel eerst een kanaal in met `/setspelkanaal spel:Telspel kanaal:#kanaal`.", ephemeral: true });
          return;
        }
        const channel = (await interaction.guild!.channels.fetch(channelId).catch(() => null)) as TextChannel | null;
        if (!channel) {
          await interaction.reply({ content: "❌ Het ingestelde kanaal voor telspel bestaat niet meer.", ephemeral: true });
          return;
        }

        if (actie === "start") {
          const existing = getCountingGame(interaction.guildId!, channelId);
          if (existing) {
            await interaction.reply({ content: `❌ Er loopt al een telspel in <#${channelId}>. Gebruik eerst \`/telspel stop\`.`, ephemeral: true });
            return;
          }
          db.prepare("INSERT INTO counting_game (guild_id, channel_id, current_count) VALUES (?, ?, 0)").run(interaction.guildId, channelId);
          await channel.send("🔢 **Telspel gestart!** Begin met tellen vanaf **1**. Niemand mag 2x achter elkaar tellen. Bij een fout begint de telling weer bij 1!");
          await interaction.reply({ content: `✅ Telspel gestart in <#${channelId}>.`, ephemeral: true });
        } else {
          const result = db.prepare("DELETE FROM counting_game WHERE guild_id = ? AND channel_id = ?").run(interaction.guildId, channelId);
          await interaction.reply({ content: result.changes ? `🛑 Telspel in <#${channelId}> gestopt.` : "Er liep geen telspel.", ephemeral: true });
        }
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("galgje")
        .setDescription("Start of stop een potje galgje in het ingestelde galgje-kanaal.")
        .addStringOption((opt) =>
          opt.setName("actie").setDescription("Starten of stoppen").setRequired(true).addChoices({ name: "Start", value: "start" }, { name: "Stop", value: "stop" })
        )
        .addStringOption((opt) => opt.setName("woord").setDescription("Eigen woord (optioneel, anders willekeurig)")),
      execute: async (interaction) => {
        const actie = interaction.options.getString("actie", true);

        const channelId = getGameChannelId(interaction.guildId!, "galgje");
        if (!channelId) {
          await interaction.reply({ content: "❌ Er is nog geen galgje-kanaal ingesteld. Vraag een staff-lid om `/setspelkanaal spel:Galgje kanaal:#kanaal` te gebruiken.", ephemeral: true });
          return;
        }
        const channel = (await interaction.guild!.channels.fetch(channelId).catch(() => null)) as TextChannel | null;
        if (!channel) {
          await interaction.reply({ content: "❌ Het ingestelde kanaal voor galgje bestaat niet meer.", ephemeral: true });
          return;
        }

        if (actie === "start") {
          const existing = getHangmanGame(interaction.guildId!, channelId);
          if (existing) {
            await interaction.reply({ content: `❌ Er loopt al een potje galgje in <#${channelId}>. Gebruik eerst \`/galgje stop\`.`, ephemeral: true });
            return;
          }
          const customWoord = interaction.options.getString("woord");
          const woord = (customWoord || HANGMAN_WORDS[Math.floor(Math.random() * HANGMAN_WORDS.length)]).toLowerCase().trim();

          db.prepare("INSERT INTO hangman_game (guild_id, channel_id, word, started_by) VALUES (?, ?, ?, ?)").run(
            interaction.guildId, channelId, woord, interaction.user.id
          );
          await interaction.reply({ content: `✅ Galgje gestart in <#${channelId}>.`, ephemeral: true });
          await channel.send("🎪 **Galgje gestart!** Typ een letter in dit kanaal om te raden.");
          await sendHangmanState(channel, { word: woord, guessed_letters: "", wrong_count: 0 });
        } else {
          const result = db.prepare("DELETE FROM hangman_game WHERE guild_id = ? AND channel_id = ?").run(interaction.guildId, channelId);
          await interaction.reply({ content: result.changes ? `🛑 Galgje in <#${channelId}> gestopt.` : "Er liep geen potje galgje.", ephemeral: true });
        }
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("raadgetal")
        .setDescription("Start of stop een 'raad het getal'-spel in het ingestelde kanaal.")
        .addStringOption((opt) =>
          opt.setName("actie").setDescription("Starten of stoppen").setRequired(true).addChoices({ name: "Start", value: "start" }, { name: "Stop", value: "stop" })
        )
        .addIntegerOption((opt) => opt.setName("min").setDescription("Laagste getal (standaard 1)"))
        .addIntegerOption((opt) => opt.setName("max").setDescription("Hoogste getal (standaard 100)")),
      execute: async (interaction) => {
        const actie = interaction.options.getString("actie", true);

        const channelId = getGameChannelId(interaction.guildId!, "raadgetal");
        if (!channelId) {
          await interaction.reply({ content: "❌ Er is nog geen kanaal ingesteld. Vraag een staff-lid om `/setspelkanaal spel:Raad het getal kanaal:#kanaal` te gebruiken.", ephemeral: true });
          return;
        }
        const channel = (await interaction.guild!.channels.fetch(channelId).catch(() => null)) as TextChannel | null;
        if (!channel) {
          await interaction.reply({ content: "❌ Het ingestelde kanaal voor dit spel bestaat niet meer.", ephemeral: true });
          return;
        }

        if (actie === "start") {
          const existing = getGuessingGame(interaction.guildId!, channelId);
          if (existing) {
            await interaction.reply({ content: `❌ Er loopt al een 'raad het getal'-spel in <#${channelId}>. Gebruik eerst \`/raadgetal stop\`.`, ephemeral: true });
            return;
          }
          const min = interaction.options.getInteger("min") ?? 1;
          const max = interaction.options.getInteger("max") ?? 100;
          if (min >= max) {
            await interaction.reply({ content: "❌ `min` moet lager zijn dan `max`.", ephemeral: true });
            return;
          }
          const target = Math.floor(Math.random() * (max - min + 1)) + min;

          db.prepare("INSERT INTO guessing_game (guild_id, channel_id, target_number, min_number, max_number) VALUES (?, ?, ?, ?, ?)").run(
            interaction.guildId, channelId, target, min, max
          );
          await channel.send(`🔮 **Raad het getal!** Ik denk aan een getal tussen **${min}** en **${max}**. Typ je gok in dit kanaal!`);
          await interaction.reply({ content: `✅ Spel gestart in <#${channelId}>.`, ephemeral: true });
        } else {
          const result = db.prepare("DELETE FROM guessing_game WHERE guild_id = ? AND channel_id = ?").run(interaction.guildId, channelId);
          await interaction.reply({ content: result.changes ? `🛑 Spel in <#${channelId}> gestopt.` : "Er liep geen 'raad het getal'-spel.", ephemeral: true });
        }
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("dobbelsteen")
        .setDescription("Gooi met een (of meerdere) dobbelsteen(en).")
        .addIntegerOption((opt) => opt.setName("zijden").setDescription("Aantal zijden per dobbelsteen (standaard 6)").setMinValue(2).setMaxValue(1000))
        .addIntegerOption((opt) => opt.setName("aantal").setDescription("Aantal dobbelstenen (standaard 1, max 10)").setMinValue(1).setMaxValue(10)),
      execute: async (interaction) => {
        const zijden = interaction.options.getInteger("zijden") ?? 6;
        const aantal = interaction.options.getInteger("aantal") ?? 1;

        const worpen = Array.from({ length: aantal }, () => Math.floor(Math.random() * zijden) + 1);
        const totaal = worpen.reduce((a, b) => a + b, 0);

        const embed = new EmbedBuilder()
          .setTitle("🎲 Dobbelsteen")
          .setColor(0x5865f2)
          .setDescription(
            aantal === 1
              ? `Je gooide een **${worpen[0]}** (van de ${zijden}-zijdige dobbelsteen)!`
              : `Worpen: ${worpen.map((w) => `**${w}**`).join(", ")}\nTotaal: **${totaal}**`
          );
        await interaction.reply({ embeds: [embed] });
      },
    },
    {
      data: new SlashCommandBuilder().setName("quote").setDescription("Toon een willekeurige inspiratie-/motivatiequote."),
      execute: async (interaction) => {
        const quote = QUOTES[Math.floor(Math.random() * QUOTES.length)];
        const embed = new EmbedBuilder().setColor(0x5865f2).setDescription(`💬 *"${quote.text}"*`).setFooter({ text: `— ${quote.author}` });
        await interaction.reply({ embeds: [embed] });
      },
    },
    {
      data: new SlashCommandBuilder().setName("kopofmunt").setDescription("Gooi een muntje op: kop of munt."),
      execute: async (interaction) => {
        const result = Math.random() < 0.5 ? "Kop 🪙" : "Munt 🪙";
        const embed = new EmbedBuilder().setTitle("🪙 Kop of munt").setColor(0x5865f2).setDescription(`Het is... **${result}**!`);
        await interaction.reply({ embeds: [embed] });
      },
    },
  ],
};

export default gamesModule;
