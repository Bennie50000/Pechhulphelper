import { SlashCommandBuilder, EmbedBuilder, GuildMember } from "discord.js";
import { BotModule } from "../types";

const generalModule: BotModule = {
  name: "general",
  commands: [
    {
      data: new SlashCommandBuilder().setName("ping").setDescription("Laat de latency van de bot zien."),
      execute: async (interaction) => {
        const latencyMs = Math.round(interaction.client.ws.ping);
        await interaction.reply(`🏓 Pong! Latency: **${latencyMs}ms**`);
      },
    },
    {
      data: new SlashCommandBuilder().setName("help").setDescription("Toon alle beschikbare commands."),
      execute: async (interaction) => {
        const embed = new EmbedBuilder()
          .setTitle("📖 Command overzicht")
          .setDescription("Hieronder alle beschikbare commands per categorie.")
          .setColor(0x5865f2)
          .addFields(
            {
              name: "🔨 Moderatie",
              value: "`/kick` `/ban` `/unban` `/mute` `/unmute` `/purge` `/setlogchannel`",
            },
            {
              name: "🛡️ Staff-toegang",
              value: "`/addstaffrole` `/removestaffrole` `/liststaffroles`",
            },
            {
              name: "🎫 Tickets",
              value:
                "`/ticketsetup` `/addtickettype` `/removetickettype` `/listtickettypes` " +
                "`/addtickettypequestion` `/removetickettypequestion` `/listtickettypequestions` " +
                "`/ticketpanel` `/closeticket`",
            },
            {
              name: "🎂 Verjaardagen",
              value: "`/setbirthday` `/removebirthday` `/birthday` `/birthdaylist` `/setbirthdaychannel`",
            },
            { name: "🎮 Speeltijd", value: "`/playtime`" },
            { name: "📋 Server logs", value: "`/setserverlogchannel`" },
            { name: "✏️ Aanpasbare berichten", value: "`/createembed` `/setembededitrole`" },
            { name: "ℹ️ Algemeen", value: "`/ping` `/help` `/serverinfo` `/userinfo` `/avatar`" }
          )
          .setFooter({ text: `Aangevraagd door ${interaction.user.username}` });
        await interaction.reply({ embeds: [embed] });
      },
    },
    {
      data: new SlashCommandBuilder().setName("serverinfo").setDescription("Toon informatie over deze server."),
      execute: async (interaction) => {
        const guild = interaction.guild;
        if (!guild) {
          await interaction.reply({ content: "Dit command werkt alleen op een server.", ephemeral: true });
          return;
        }
        const owner = await guild.fetchOwner();
        const embed = new EmbedBuilder()
          .setTitle(`📊 ${guild.name}`)
          .setColor(0x57f287)
          .addFields(
            { name: "Eigenaar", value: owner.user.tag, inline: true },
            { name: "Leden", value: String(guild.memberCount), inline: true },
            { name: "Aangemaakt op", value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`, inline: true },
            { name: "Kanalen", value: String(guild.channels.cache.size), inline: true },
            { name: "Rollen", value: String(guild.roles.cache.size), inline: true },
            { name: "Server ID", value: guild.id, inline: true }
          );
        if (guild.iconURL()) embed.setThumbnail(guild.iconURL());
        await interaction.reply({ embeds: [embed] });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("userinfo")
        .setDescription("Toon informatie over een gebruiker.")
        .addUserOption((opt) => opt.setName("member").setDescription("De gebruiker (standaard: jijzelf)")),
      execute: async (interaction) => {
        const targetUser = interaction.options.getUser("member") ?? interaction.user;
        const member = (interaction.guild?.members.cache.get(targetUser.id) ??
          (await interaction.guild?.members.fetch(targetUser.id).catch(() => null))) as GuildMember | null;

        const embed = new EmbedBuilder()
          .setTitle(`👤 ${member?.displayName ?? targetUser.username}`)
          .setColor(member?.displayColor || 0x5865f2)
          .setThumbnail(targetUser.displayAvatarURL())
          .addFields(
            { name: "Gebruikersnaam", value: targetUser.tag, inline: true },
            { name: "ID", value: targetUser.id, inline: true },
            { name: "Bot?", value: targetUser.bot ? "Ja" : "Nee", inline: true }
          );
        if (member?.joinedTimestamp) {
          embed.addFields({ name: "Lid geworden op", value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:D>`, inline: true });
        }
        embed.addFields({ name: "Account aangemaakt", value: `<t:${Math.floor(targetUser.createdTimestamp / 1000)}:D>`, inline: true });

        if (member) {
          const roles = member.roles.cache.filter((r) => r.name !== "@everyone").map((r) => r.toString());
          embed.addFields({ name: `Rollen (${roles.length})`, value: roles.length ? roles.join(" ") : "Geen" });
        }
        await interaction.reply({ embeds: [embed] });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("avatar")
        .setDescription("Toon de avatar van een gebruiker.")
        .addUserOption((opt) => opt.setName("member").setDescription("De gebruiker (standaard: jijzelf)")),
      execute: async (interaction) => {
        const targetUser = interaction.options.getUser("member") ?? interaction.user;
        const embed = new EmbedBuilder()
          .setTitle(`Avatar van ${targetUser.username}`)
          .setColor(0x5865f2)
          .setImage(targetUser.displayAvatarURL({ size: 512 }));
        await interaction.reply({ embeds: [embed] });
      },
    },
  ],
};

export default generalModule;
