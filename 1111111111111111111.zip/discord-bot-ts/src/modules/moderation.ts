import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType, GuildMember, TextChannel, Guild } from "discord.js";
import { BotModule } from "../types";
import { requireStaff } from "../permissions";
import { db } from "../database";

// ---------- Helpers ----------

async function getLogChannel(guild: Guild): Promise<TextChannel | null> {
  const row = db.prepare("SELECT log_channel_id FROM mod_config WHERE guild_id = ?").get(guild.id) as any;
  if (!row?.log_channel_id) return null;
  const channel = await guild.channels.fetch(row.log_channel_id).catch(() => null);
  return channel?.isTextBased() ? (channel as TextChannel) : null;
}

async function sendLog(guild: Guild, embed: EmbedBuilder): Promise<void> {
  const channel = await getLogChannel(guild);
  if (channel) await channel.send({ embeds: [embed] }).catch(() => {});
}

// ---------- Module ----------

const moderationModule: BotModule = {
  name: "moderation",
  commands: [
    {
      data: new SlashCommandBuilder()
        .setName("setlogchannel")
        .setDescription("Stel het kanaal in voor moderatie-logs.")
        .addChannelOption((opt) =>
          opt.setName("channel").setDescription("Het logkanaal").addChannelTypes(ChannelType.GuildText).setRequired(true)
        ),
      execute: async (interaction) => {
        if (!(await requireStaff(interaction))) return;
        const channel = interaction.options.getChannel("channel", true);
        db.prepare(
          `INSERT INTO mod_config (guild_id, log_channel_id) VALUES (?, ?)
           ON CONFLICT(guild_id) DO UPDATE SET log_channel_id = excluded.log_channel_id`
        ).run(interaction.guildId, channel.id);
        await interaction.reply({ content: `✅ Logkanaal ingesteld op <#${channel.id}>.`, ephemeral: true });
      },
    },

    // ---------- Kick / Ban ----------
    {
      data: new SlashCommandBuilder()
        .setName("kick")
        .setDescription("Kick een lid van de server.")
        .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
        .addUserOption((opt) => opt.setName("member").setDescription("Lid om te kicken").setRequired(true))
        .addStringOption((opt) => opt.setName("reason").setDescription("Reden")),
      execute: async (interaction) => {
        const member = interaction.options.getMember("member") as GuildMember;
        const reason = interaction.options.getString("reason") ?? "Geen reden opgegeven";
        await member.kick(reason);
        await interaction.reply(`👢 **${member.user.tag}** is gekickt. Reden: ${reason}`);
        const embed = new EmbedBuilder()
          .setTitle("👢 Lid gekickt")
          .setColor(0xe67e22)
          .addFields(
            { name: "Gebruiker", value: member.user.tag, inline: true },
            { name: "Moderator", value: interaction.user.tag, inline: true },
            { name: "Reden", value: reason }
          );
        await sendLog(interaction.guild!, embed);
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("ban")
        .setDescription("Ban een lid van de server.")
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
        .addUserOption((opt) => opt.setName("member").setDescription("Lid om te bannen").setRequired(true))
        .addStringOption((opt) => opt.setName("reason").setDescription("Reden")),
      execute: async (interaction) => {
        const member = interaction.options.getMember("member") as GuildMember;
        const reason = interaction.options.getString("reason") ?? "Geen reden opgegeven";
        await member.ban({ reason });
        await interaction.reply(`🔨 **${member.user.tag}** is verbannen. Reden: ${reason}`);
        const embed = new EmbedBuilder()
          .setTitle("🔨 Lid verbannen")
          .setColor(0xed4245)
          .addFields(
            { name: "Gebruiker", value: member.user.tag, inline: true },
            { name: "Moderator", value: interaction.user.tag, inline: true },
            { name: "Reden", value: reason }
          );
        await sendLog(interaction.guild!, embed);
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("unban")
        .setDescription("Hef een ban op via user ID.")
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
        .addStringOption((opt) => opt.setName("user_id").setDescription("Het Discord ID van de gebruiker").setRequired(true)),
      execute: async (interaction) => {
        const userId = interaction.options.getString("user_id", true);
        try {
          await interaction.guild!.bans.remove(userId);
          await interaction.reply(`✅ Gebruiker met ID ${userId} is unbanned.`);
        } catch {
          await interaction.reply({ content: "❌ Kon deze gebruiker niet unbannen (verkeerd ID?).", ephemeral: true });
        }
      },
    },

    // ---------- Mute ----------
    {
      data: new SlashCommandBuilder()
        .setName("mute")
        .setDescription("Mute (timeout) een lid.")
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
        .addUserOption((opt) => opt.setName("member").setDescription("Lid om te muten").setRequired(true))
        .addIntegerOption((opt) => opt.setName("minutes").setDescription("Aantal minuten").setMinValue(1).setRequired(true))
        .addStringOption((opt) => opt.setName("reason").setDescription("Reden")),
      execute: async (interaction) => {
        const member = interaction.options.getMember("member") as GuildMember;
        const minutes = interaction.options.getInteger("minutes", true);
        const reason = interaction.options.getString("reason") ?? "Geen reden opgegeven";
        await member.timeout(minutes * 60 * 1000, reason);
        await interaction.reply(`🔇 **${member.user.tag}** is gemute voor ${minutes} minuten. Reden: ${reason}`);
        const embed = new EmbedBuilder()
          .setTitle("🔇 Lid gemute")
          .setColor(0x99aab5)
          .addFields(
            { name: "Gebruiker", value: member.user.tag, inline: true },
            { name: "Duur", value: `${minutes} minuten`, inline: true },
            { name: "Reden", value: reason }
          );
        await sendLog(interaction.guild!, embed);
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("unmute")
        .setDescription("Hef een mute/timeout op.")
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
        .addUserOption((opt) => opt.setName("member").setDescription("Lid om te unmuten").setRequired(true)),
      execute: async (interaction) => {
        const member = interaction.options.getMember("member") as GuildMember;
        await member.timeout(null);
        await interaction.reply(`🔊 **${member.user.tag}** is unmuted.`);
      },
    },

    // ---------- Purge ----------
    {
      data: new SlashCommandBuilder()
        .setName("purge")
        .setDescription("Verwijder een aantal berichten in dit kanaal.")
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
        .addIntegerOption((opt) => opt.setName("aantal").setDescription("Hoeveel berichten verwijderen (max 100)").setMinValue(1).setMaxValue(100).setRequired(true)),
      execute: async (interaction) => {
        const aantal = interaction.options.getInteger("aantal", true);
        await interaction.deferReply({ ephemeral: true });
        const channel = interaction.channel as TextChannel;
        const deleted = await channel.bulkDelete(aantal, true);
        await interaction.editReply(`🧹 ${deleted.size} berichten verwijderd.`);
      },
    },
  ],
};

export default moderationModule;
