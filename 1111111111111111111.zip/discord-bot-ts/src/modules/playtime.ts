import { SlashCommandBuilder, EmbedBuilder, Client, Events, ActivityType, Presence } from "discord.js";
import { BotModule } from "../types";
import { db } from "../database";

// Actieve sessies bijhouden in het geheugen: sleutel = `${guildId}:${userId}:${game}` -> starttijd (ms)
const activeSessions = new Map<string, number>();

function sessionKey(guildId: string, userId: string, game: string): string {
  return `${guildId}:${userId}:${game}`;
}

function addPlaytime(guildId: string, userId: string, game: string, seconds: number): void {
  if (seconds <= 0) return;
  db.prepare(
    `INSERT INTO game_playtime (guild_id, user_id, game_name, seconds) VALUES (?, ?, ?, ?)
     ON CONFLICT(guild_id, user_id, game_name) DO UPDATE SET seconds = seconds + excluded.seconds`
  ).run(guildId, userId, game, Math.round(seconds));
}

function formatDuration(totalSeconds: number): string {
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = Math.floor(totalSeconds % 60);
  return `${hours}h ${minutes}m ${seconds}s`;
}

/** Geeft de huidige (nog lopende) speeltijd van een sessie terug, in seconden. */
function getOngoingSeconds(guildId: string, userId: string, game: string): number {
  const key = sessionKey(guildId, userId, game);
  const start = activeSessions.get(key);
  if (!start) return 0;
  return (Date.now() - start) / 1000;
}

function handlePresenceUpdate(oldPresence: Presence | null, newPresence: Presence): void {
  const guildId = newPresence.guild?.id;
  const userId = newPresence.userId;
  if (!guildId || !userId) return;

  const oldGames = new Set(
    (oldPresence?.activities ?? []).filter((a) => a.type === ActivityType.Playing).map((a) => a.name)
  );
  const newGames = new Set(
    newPresence.activities.filter((a) => a.type === ActivityType.Playing).map((a) => a.name)
  );

  // Games die gestopt zijn: sessie afsluiten en tijd opslaan
  for (const game of oldGames) {
    if (!newGames.has(game)) {
      const key = sessionKey(guildId, userId, game);
      const start = activeSessions.get(key);
      if (start) {
        addPlaytime(guildId, userId, game, (Date.now() - start) / 1000);
        activeSessions.delete(key);
      }
    }
  }

  // Games die net gestart zijn: sessie starten
  for (const game of newGames) {
    if (!oldGames.has(game)) {
      activeSessions.set(sessionKey(guildId, userId, game), Date.now());
    }
  }
}

/** Slaat alle nog lopende sessies op (bv. bij het afsluiten van de bot). */
function flushAllSessions(): void {
  for (const [key, start] of activeSessions.entries()) {
    const [guildId, userId, game] = key.split(":");
    addPlaytime(guildId, userId, game, (Date.now() - start) / 1000);
  }
  activeSessions.clear();
}

function getTopGames(guildId: string, userId: string, limit: number): Array<{ game_name: string; seconds: number }> {
  const rows = db
    .prepare("SELECT game_name, seconds FROM game_playtime WHERE guild_id = ? AND user_id = ?")
    .all(guildId, userId) as Array<{ game_name: string; seconds: number }>;

  // Lopende sessies meetellen zodat de weergave live aanvoelt
  const withOngoing = rows.map((row) => ({
    game_name: row.game_name,
    seconds: row.seconds + getOngoingSeconds(guildId, userId, row.game_name),
  }));

  // Games die nu spelen maar nog geen opgeslagen tijd hebben, ook meenemen
  for (const [key, start] of activeSessions.entries()) {
    const [kGuild, kUser, kGame] = key.split(":");
    if (kGuild === guildId && kUser === userId && !withOngoing.some((r) => r.game_name === kGame)) {
      withOngoing.push({ game_name: kGame, seconds: (Date.now() - start) / 1000 });
    }
  }

  return withOngoing.sort((a, b) => b.seconds - a.seconds).slice(0, limit);
}

const playtimeModule: BotModule = {
  name: "playtime",
  onReady: (client: Client) => {
    client.on(Events.PresenceUpdate, (oldPresence, newPresence) => {
      handlePresenceUpdate(oldPresence, newPresence);
    });
    process.on("SIGINT", () => {
      flushAllSessions();
      process.exit(0);
    });
    process.on("SIGTERM", () => {
      flushAllSessions();
      process.exit(0);
    });
  },
  commands: [
    {
      data: new SlashCommandBuilder()
        .setName("playtime")
        .setDescription("Toon de top 3 games (speeltijd) van een lid.")
        .addUserOption((opt) => opt.setName("member").setDescription("Lid om te bekijken (standaard: jijzelf)")),
      execute: async (interaction) => {
        const target = interaction.options.getUser("member") ?? interaction.user;
        const topGames = getTopGames(interaction.guildId!, target.id, 3);

        if (topGames.length === 0) {
          await interaction.reply(`Nog geen speeltijd geregistreerd voor **${target.username}**.`);
          return;
        }

        const embed = new EmbedBuilder()
          .setTitle(`🎮 Speeltijd — ${target.username}`)
          .setColor(0x5865f2)
          .setThumbnail(target.displayAvatarURL());

        for (const row of topGames) {
          embed.addFields({
            name: row.game_name,
            value: `Speelt\n**${formatDuration(row.seconds)}**`,
            inline: true,
          });
        }

        await interaction.reply({ embeds: [embed] });
      },
    },
  ],
};

export default playtimeModule;
