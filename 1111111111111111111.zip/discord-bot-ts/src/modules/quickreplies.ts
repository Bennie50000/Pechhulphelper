import {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ButtonInteraction,
  TextChannel,
} from "discord.js";
import { BotModule } from "../types";
import { requireStaff } from "../permissions";
import { db } from "../database";

const BUTTON_PREFIX = "quickreply_";

const STYLE_MAP: Record<string, ButtonStyle> = {
  primary: ButtonStyle.Primary,
  secondary: ButtonStyle.Secondary,
  success: ButtonStyle.Success,
  danger: ButtonStyle.Danger,
};

function getButtons(guildId: string): any[] {
  return db.prepare("SELECT * FROM quick_reply_buttons WHERE guild_id = ? ORDER BY id").all(guildId) as any[];
}

function buildButtonRows(buttons: any[]): ActionRowBuilder<ButtonBuilder>[] {
  const rows: ActionRowBuilder<ButtonBuilder>[] = [];
  for (let i = 0; i < buttons.length; i += 5) {
    const chunk = buttons.slice(i, i + 5);
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      chunk.map((b) => {
        const button = new ButtonBuilder()
          .setCustomId(`${BUTTON_PREFIX}${b.id}`)
          .setLabel(b.label)
          .setStyle(STYLE_MAP[b.style] ?? ButtonStyle.Primary);
        if (b.emoji) button.setEmoji(b.emoji);
        return button;
      })
    );
    rows.push(row);
  }
  return rows;
}

async function handleButton(interaction: ButtonInteraction): Promise<boolean> {
  if (!interaction.customId.startsWith(BUTTON_PREFIX)) return false;

  const id = Number(interaction.customId.slice(BUTTON_PREFIX.length));
  const row = db.prepare("SELECT * FROM quick_reply_buttons WHERE id = ? AND guild_id = ?").get(id, interaction.guildId) as any;

  if (!row) {
    await interaction.reply({ content: "❌ Deze knop bestaat niet meer.", ephemeral: true });
    return true;
  }

  // Gewoon bericht in het kanaal, zichtbaar voor iedereen — dit IS de "klik = kant-en-klaar antwoord"-functie.
  await interaction.reply({ content: row.message_content });
  return true;
}

const quickrepliesModule: BotModule = {
  name: "quickreplies",
  handleButton,
  commands: [
    {
      data: new SlashCommandBuilder()
        .setName("addbutton")
        .setDescription("Voeg een snelle-antwoord-knop toe (klik = kant-en-klaar bericht sturen).")
        .addStringOption((opt) => opt.setName("label").setDescription("Tekst op de knop (bv. 'FAQ regels')").setRequired(true))
        .addStringOption((opt) => opt.setName("message").setDescription("Het bericht dat verstuurd wordt bij een klik").setRequired(true))
        .addStringOption((opt) => opt.setName("emoji").setDescription("Emoji op de knop (optioneel)"))
        .addStringOption((opt) =>
          opt
            .setName("style")
            .setDescription("Kleur van de knop (optioneel, standaard blauw)")
            .addChoices(
              { name: "Blauw", value: "primary" },
              { name: "Grijs", value: "secondary" },
              { name: "Groen", value: "success" },
              { name: "Rood", value: "danger" }
            )
        ),
      execute: async (interaction) => {
        if (!(await requireStaff(interaction))) return;

        const label = interaction.options.getString("label", true);
        const message = interaction.options.getString("message", true);
        const emoji = interaction.options.getString("emoji");
        const style = interaction.options.getString("style") ?? "primary";

        const { c: count } = db.prepare("SELECT COUNT(*) as c FROM quick_reply_buttons WHERE guild_id = ?").get(interaction.guildId) as { c: number };
        if (count >= 25) {
          await interaction.reply({ content: "❌ Je hebt al 25 knoppen (het maximum op één paneel).", ephemeral: true });
          return;
        }

        db.prepare("INSERT INTO quick_reply_buttons (guild_id, label, message_content, emoji, style) VALUES (?, ?, ?, ?, ?)").run(
          interaction.guildId,
          label,
          message,
          emoji,
          style
        );

        await interaction.reply({
          content: `✅ Knop **${label}** toegevoegd. Gebruik \`/buttonpanel\` om het paneel (opnieuw) te plaatsen zodat deze knop zichtbaar wordt.`,
          ephemeral: true,
        });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("removebutton")
        .setDescription("Verwijder een snelle-antwoord-knop.")
        .addStringOption((opt) => opt.setName("label").setDescription("Exacte naam van de te verwijderen knop").setRequired(true)),
      execute: async (interaction) => {
        if (!(await requireStaff(interaction))) return;

        const label = interaction.options.getString("label", true);
        const result = db.prepare("DELETE FROM quick_reply_buttons WHERE guild_id = ? AND label = ?").run(interaction.guildId, label);
        if (result.changes === 0) {
          await interaction.reply({ content: `❌ Geen knop gevonden met naam '${label}'.`, ephemeral: true });
        } else {
          await interaction.reply({ content: `🗑️ Knop **${label}** verwijderd. Gebruik \`/buttonpanel\` om het paneel opnieuw te plaatsen.`, ephemeral: true });
        }
      },
    },
    {
      data: new SlashCommandBuilder().setName("listbuttons").setDescription("Toon alle ingestelde snelle-antwoord-knoppen."),
      execute: async (interaction) => {
        if (!(await requireStaff(interaction))) return;

        const buttons = getButtons(interaction.guildId!);
        if (buttons.length === 0) {
          await interaction.reply({ content: "Nog geen knoppen ingesteld. Gebruik `/addbutton`.", ephemeral: true });
          return;
        }
        const embed = new EmbedBuilder().setTitle("🔘 Snelle-antwoord-knoppen").setColor(0x5865f2);
        for (const b of buttons) {
          embed.addFields({ name: `${b.emoji ? b.emoji + " " : ""}${b.label}`, value: b.message_content.slice(0, 200) });
        }
        await interaction.reply({ embeds: [embed], ephemeral: true });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("buttonpanel")
        .setDescription("Plaats het knoppenpaneel in dit kanaal.")
        .addStringOption((opt) => opt.setName("title").setDescription("Titel boven de knoppen (optioneel)")),
      execute: async (interaction) => {
        if (!(await requireStaff(interaction))) return;

        const buttons = getButtons(interaction.guildId!);
        if (buttons.length === 0) {
          await interaction.reply({ content: "❌ Voeg eerst knoppen toe met `/addbutton`.", ephemeral: true });
          return;
        }

        const title = interaction.options.getString("title");
        const channel = interaction.channel as TextChannel;
        const rows = buildButtonRows(buttons);

        if (title) {
          const embed = new EmbedBuilder().setTitle(title).setColor(0x5865f2);
          await channel.send({ embeds: [embed], components: rows });
        } else {
          await channel.send({ components: rows });
        }

        await interaction.reply({ content: "✅ Knoppenpaneel geplaatst.", ephemeral: true });
      },
    },
  ],
};

export default quickrepliesModule;
