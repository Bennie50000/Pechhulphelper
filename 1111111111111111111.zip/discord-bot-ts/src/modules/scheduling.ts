import {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ButtonInteraction,
  UserSelectMenuBuilder,
  UserSelectMenuInteraction,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ModalSubmitInteraction,
  Message,
  TextChannel,
} from "discord.js";
import { BotModule } from "../types";
import { requireStaff } from "../permissions";
import { INACTIVITY_CHANNEL_ID, INACTIVITY_ROLE_ID, BASISTRAINING_CHANNEL_ID, BASISTRAINING_ROLE_ID, SOLLICITANT_ROLE_ID, MEDEDELINGEN_CHANNEL_ID, WACHTKAMER_CHANNEL_ID } from "../config";

const START_BUTTON_ID = "plangesprek_start";
const AFGELAST_BUTTON_ID = "actiepaneel_afgelast";
const AFGELAST_MODAL_ID = "actiepaneel_afgelast_modal";
const INACTIVITY_BUTTON_ID = "actiepaneel_inactiviteit";
const BASISTRAINING_BUTTON_ID = "actiepaneel_basistraining";
const BASISTRAINING_MODAL_ID = "actiepaneel_basistraining_modal";
const SELECT_BEGELEIDERS_ID = "plangesprek_select_begeleiders";
const NEXT_BUTTON_ID = "plangesprek_next";
const MODAL_ID = "plangesprek_modal";

interface Draft {
  begeleiderIds: string[];
}

// Tijdelijke opslag tussen de stappen (knop -> keuzemenu -> formulier), per gebruiker.
// Gaat verloren bij herstart van de bot, maar dat is voor dit korte invulproces geen probleem.
const drafts = new Map<string, Draft>();

function draftKey(guildId: string, userId: string): string {
  return `${guildId}:${userId}`;
}

function buildSelectComponents(draft: Draft) {
  const begeleidersMenu = new UserSelectMenuBuilder()
    .setCustomId(SELECT_BEGELEIDERS_ID)
    .setPlaceholder("Kies begeleider(s) (max 3)")
    .setMinValues(1)
    .setMaxValues(3);
  if (draft.begeleiderIds.length > 0) begeleidersMenu.setDefaultUsers(draft.begeleiderIds);

  const nextRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(NEXT_BUTTON_ID).setLabel("Volgende: dag/tijd invullen →").setStyle(ButtonStyle.Success)
  );

  return [new ActionRowBuilder<UserSelectMenuBuilder>().addComponents(begeleidersMenu), nextRow];
}

function statusText(draft: Draft): string {
  const lines = ["**Gesprek plannen — stap 1/2**", ""];
  lines.push(`Kandidaat: de sollicitanten-rol wordt automatisch getagd`);
  lines.push(`Begeleider(s): ${draft.begeleiderIds.length ? draft.begeleiderIds.map((id) => `<@${id}>`).join(", ") : "*(nog niet gekozen)*"}`);
  lines.push("", "Kies hieronder, en klik daarna op **Volgende**.");
  return lines.join("\n");
}

async function handleButton(interaction: ButtonInteraction): Promise<boolean> {
  if (interaction.customId === AFGELAST_BUTTON_ID) {
    if (!BASISTRAINING_CHANNEL_ID || !SOLLICITANT_ROLE_ID) {
      await interaction.reply({
        content: "❌ `BASISTRAINING_CHANNEL_ID` en/of `SOLLICITANT_ROLE_ID` staan nog niet ingesteld in `.env`.",
        ephemeral: true,
      });
      return true;
    }

    const modal = new ModalBuilder().setCustomId(AFGELAST_MODAL_ID).setTitle("Gesprek/training afgelasten");
    const tijdInput = new TextInputBuilder()
      .setCustomId("tijd")
      .setLabel("Om welke tijd zou het zijn? (bv. 19:00)")
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setValue("19:00");
    const redenInput = new TextInputBuilder()
      .setCustomId("reden")
      .setLabel("Reden van afgelasting")
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setValue("familieomstandigheden");

    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(tijdInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(redenInput)
    );
    await interaction.showModal(modal);
    return true;
  }

  if (interaction.customId === INACTIVITY_BUTTON_ID) {
    if (!INACTIVITY_CHANNEL_ID || !INACTIVITY_ROLE_ID) {
      await interaction.reply({
        content: "❌ `INACTIVITY_CHANNEL_ID` en/of `INACTIVITY_ROLE_ID` staan nog niet ingesteld in `.env`.",
        ephemeral: true,
      });
      return true;
    }

    const channel = await interaction.guild?.channels.fetch(INACTIVITY_CHANNEL_ID).catch(() => null);
    if (!channel || !channel.isTextBased()) {
      await interaction.reply({ content: "❌ Het ingestelde `INACTIVITY_CHANNEL_ID` kanaal is niet gevonden.", ephemeral: true });
      return true;
    }

    const message = [
      `<@&${INACTIVITY_ROLE_ID}> `,
      "Je hebt je uren deze week niet gehaald.",
      "Dat betekent dat je deze week extra hard bezig moet gaan met uren halen.",
      "⚠️Anders ben je ontslagen!⚠️",
    ].join("\n");

    await (channel as TextChannel).send({ content: message });
    await interaction.reply({ content: `✅ Inactiviteitsbericht verstuurd in <#${INACTIVITY_CHANNEL_ID}>.`, ephemeral: true });
    return true;
  }

  if (interaction.customId === BASISTRAINING_BUTTON_ID) {
    if (!BASISTRAINING_CHANNEL_ID || !BASISTRAINING_ROLE_ID) {
      await interaction.reply({
        content: "❌ `BASISTRAINING_CHANNEL_ID` en/of `BASISTRAINING_ROLE_ID` staan nog niet ingesteld in `.env`.",
        ephemeral: true,
      });
      return true;
    }

    const modal = new ModalBuilder().setCustomId(BASISTRAINING_MODAL_ID).setTitle("Basistraining reminder");
    const minutenInput = new TextInputBuilder()
      .setCustomId("minuten")
      .setLabel("Over hoeveel minuten beginnen de gesprekken?")
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setValue("10");
    modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(minutenInput));
    await interaction.showModal(modal);
    return true;
  }

  if (interaction.customId === START_BUTTON_ID) {
    if (!SOLLICITANT_ROLE_ID) {
      await interaction.reply({ content: "❌ `SOLLICITANT_ROLE_ID` staat nog niet ingesteld in `.env`.", ephemeral: true });
      return true;
    }
    const key = draftKey(interaction.guildId!, interaction.user.id);
    const draft: Draft = { begeleiderIds: [] };
    drafts.set(key, draft);
    await interaction.reply({ content: statusText(draft), components: buildSelectComponents(draft), ephemeral: true });
    return true;
  }

  if (interaction.customId === NEXT_BUTTON_ID) {
    const key = draftKey(interaction.guildId!, interaction.user.id);
    const draft = drafts.get(key);
    if (!draft || draft.begeleiderIds.length === 0) {
      await interaction.reply({ content: "❌ Kies eerst minstens 1 begeleider hierboven.", ephemeral: true });
      return true;
    }

    const modal = new ModalBuilder().setCustomId(MODAL_ID).setTitle("Gesprek plannen — stap 2/2");
    const dagInput = new TextInputBuilder().setCustomId("dag").setLabel("Dag (bv. 'Vrijdag' of '12 september')").setStyle(TextInputStyle.Short).setRequired(true);
    const tijdInput = new TextInputBuilder().setCustomId("tijd").setLabel("Tijd (bv. '19:00')").setStyle(TextInputStyle.Short).setRequired(true);
    const typeInput = new TextInputBuilder()
      .setCustomId("type")
      .setLabel("Type sessie (optioneel)")
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setValue("Gesprek / Basistraining");
    const duurInput = new TextInputBuilder()
      .setCustomId("duur")
      .setLabel("Verwachte duur (optioneel)")
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setValue("ongeveer 1 uur");

    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(dagInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(tijdInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(typeInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(duurInput)
    );
    await interaction.showModal(modal);
    return true;
  }

  return false;
}

async function handleUserSelectMenu(interaction: UserSelectMenuInteraction): Promise<boolean> {
  if (interaction.customId !== SELECT_BEGELEIDERS_ID) return false;
  const key = draftKey(interaction.guildId!, interaction.user.id);
  const draft = drafts.get(key);
  if (!draft) return false;

  draft.begeleiderIds = interaction.values;
  await interaction.update({ content: statusText(draft), components: buildSelectComponents(draft) });
  return true;
}

async function handleModalSubmit(interaction: ModalSubmitInteraction): Promise<boolean> {
  if (interaction.customId === AFGELAST_MODAL_ID) {
    const tijd = interaction.fields.getTextInputValue("tijd").trim();
    const reden = interaction.fields.getTextInputValue("reden").trim();

    const channel = await interaction.guild?.channels.fetch(BASISTRAINING_CHANNEL_ID!).catch(() => null);
    if (!channel || !channel.isTextBased()) {
      await interaction.reply({ content: "❌ Het ingestelde `BASISTRAINING_CHANNEL_ID` kanaal is niet gevonden.", ephemeral: true });
      return true;
    }

    const mededelingenLink = MEDEDELINGEN_CHANNEL_ID ? `<#${MEDEDELINGEN_CHANNEL_ID}>` : "het mededelingen-kanaal";

    const lines = [
      "# ⚠️ GESPREK / BASISTRAINING – AFGELAST",
      "",
      `Beste <@&${SOLLICITANT_ROLE_ID}>,`,
      "",
      `Helaas moeten we mededelen dat het **Gesprek / de Basistraining van vandaag om ${tijd} uur niet doorgaat wegens ${reden}.**`,
      "",
      `De training is daarom afgelast. Zodra er meer bekend is over een nieuw moment, laten we dit zo snel mogelijk weten. Houd hiervoor ${mededelingenLink} goed in de gaten. 🔔`,
      "",
      "Bedankt voor jullie begrip! 🙏",
      "",
      "Met vriendelijke groet,",
      `${interaction.user}`,
    ];

    await (channel as TextChannel).send({ content: lines.join("\n") });
    await interaction.reply({ content: `✅ Afgelast-bericht verstuurd in <#${BASISTRAINING_CHANNEL_ID}>.`, ephemeral: true });
    return true;
  }

  if (interaction.customId === BASISTRAINING_MODAL_ID) {
    const minuten = interaction.fields.getTextInputValue("minuten").trim();

    const channel = await interaction.guild?.channels.fetch(BASISTRAINING_CHANNEL_ID!).catch(() => null);
    if (!channel || !channel.isTextBased()) {
      await interaction.reply({ content: "❌ Het ingestelde `BASISTRAINING_CHANNEL_ID` kanaal is niet gevonden.", ephemeral: true });
      return true;
    }

    const link = `https://discord.com/channels/${interaction.guildId}/${BASISTRAINING_CHANNEL_ID}`;
    const message = [
      `<@&${BASISTRAINING_ROLE_ID}> **REMINDER**`,
      `De gesprekken beginnen over **${minuten} minuten**!`,
      `Join alvast: ${link} zodat we zo direct kunnen starten.`,
      "❗ **Belangrijk:**",
      "Je dient tijdens het gesprek ook aanwezig te zijn **in-game op het Pechhulp HB**.",
    ].join("\n");

    await (channel as TextChannel).send({ content: message });
    await interaction.reply({ content: `✅ Basistraining-reminder verstuurd in <#${BASISTRAINING_CHANNEL_ID}>.`, ephemeral: true });
    return true;
  }

  if (interaction.customId !== MODAL_ID) return false;

  const key = draftKey(interaction.guildId!, interaction.user.id);
  const draft = drafts.get(key);
  if (!draft || draft.begeleiderIds.length === 0 || !SOLLICITANT_ROLE_ID) {
    await interaction.reply({ content: "❌ Er ging iets mis, begin opnieuw met de knop.", ephemeral: true });
    return true;
  }

  if (!BASISTRAINING_CHANNEL_ID) {
    await interaction.reply({ content: "❌ `BASISTRAINING_CHANNEL_ID` staat nog niet ingesteld in `.env` — dat kanaal wordt ook gebruikt voor deze uitnodiging.", ephemeral: true });
    return true;
  }
  const channel = (await interaction.guild!.channels.fetch(BASISTRAINING_CHANNEL_ID).catch(() => null)) as TextChannel | null;
  if (!channel) {
    await interaction.reply({ content: "❌ Het ingestelde `BASISTRAINING_CHANNEL_ID` kanaal is niet gevonden.", ephemeral: true });
    return true;
  }

  const dag = interaction.fields.getTextInputValue("dag");
  const tijd = interaction.fields.getTextInputValue("tijd");
  const type = interaction.fields.getTextInputValue("type") || "Gesprek / Basistraining";
  const duur = interaction.fields.getTextInputValue("duur") || "ongeveer 1 uur";

  const begeleidersText = draft.begeleiderIds.map((id) => `<@${id}>`).join(" & ");

  const lines = [
    `Beste <@&${SOLLICITANT_ROLE_ID}>,`,
    "",
    `**${dag} om ${tijd} uur** 🕐 vindt er een *${type}* plaats.`,
    "Zorg dat je op tijd in de wachtkamer aanwezig bent; je wordt vanzelf naar het gesprek gesleept. 🧙",
    "",
    `De training zal worden afgenomen door ${begeleidersText}. + mogelijk andere docenten.`,
    "",
    "⚠️ **Belangrijk:**",
    `Wanneer je het gesprek succesvol doorloopt, duurt de volledige training ${duur}.`,
    "",
    "Laat even weten of je erbij bent:",
    "Ja ✅ of Nee ❌",
    "",
    "Als je reageert met een vinkje of kruisje, gaan we ervan uit dat je aanwezig bent of juist niet komt.",
  ];
  if (WACHTKAMER_CHANNEL_ID) lines.push("", `<#${WACHTKAMER_CHANNEL_ID}>`);

  const sentMessage = (await channel.send({ content: lines.join("\n") })) as Message;
  await sentMessage.react("✅").catch(() => {});
  await sentMessage.react("❌").catch(() => {});

  drafts.delete(key);
  await interaction.reply({ content: `✅ Gesprek gepland en bericht verstuurd in <#${BASISTRAINING_CHANNEL_ID}>!`, ephemeral: true });
  return true;
}

const schedulingModule: BotModule = {
  name: "scheduling",
  handleButton,
  handleUserSelectMenu,
  handleModalSubmit,
  commands: [
    {
      data: new SlashCommandBuilder()
        .setName("actiepaneel")
        .setDescription("Plaats een paneel met knoppen: gesprek plannen, inactiviteitsbericht, enz."),
      execute: async (interaction) => {
        if (!(await requireStaff(interaction))) return;
        const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
          new ButtonBuilder().setCustomId(START_BUTTON_ID).setLabel("📅 Plan gesprek").setStyle(ButtonStyle.Primary),
          new ButtonBuilder().setCustomId(BASISTRAINING_BUTTON_ID).setLabel("🎓 Basistraining reminder").setStyle(ButtonStyle.Success),
          new ButtonBuilder().setCustomId(AFGELAST_BUTTON_ID).setLabel("🚫 Afgelast").setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId(INACTIVITY_BUTTON_ID).setLabel("⚠️ Inactiviteit").setStyle(ButtonStyle.Danger)
        );
        const channel = interaction.channel as TextChannel;
        await channel.send({ components: [row] });
        await interaction.reply({ content: "✅ Paneel geplaatst.", ephemeral: true });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("plangesprek")
        .setDescription("Plan direct een gesprek/training in via slash-command opties (zonder knoppen).")
        .addStringOption((opt) => opt.setName("dag").setDescription("Bv. 'Vrijdag' of '12 september'").setRequired(true))
        .addStringOption((opt) => opt.setName("tijd").setDescription("Bv. '19:00'").setRequired(true))
        .addUserOption((opt) => opt.setName("begeleider1").setDescription("Eerste begeleider/afnemer").setRequired(true))
        .addUserOption((opt) => opt.setName("begeleider2").setDescription("Tweede begeleider/afnemer (optioneel)"))
        .addUserOption((opt) => opt.setName("begeleider3").setDescription("Derde begeleider/afnemer (optioneel)"))
        .addStringOption((opt) => opt.setName("type").setDescription("Wat voor sessie het is (standaard: 'Gesprek / Basistraining')"))
        .addStringOption((opt) => opt.setName("duur").setDescription("Verwachte duur (standaard: 'ongeveer 1 uur')")),
      execute: async (interaction) => {
        if (!(await requireStaff(interaction))) return;

        if (!SOLLICITANT_ROLE_ID) {
          await interaction.reply({ content: "❌ `SOLLICITANT_ROLE_ID` staat nog niet ingesteld in `.env`.", ephemeral: true });
          return;
        }
        if (!BASISTRAINING_CHANNEL_ID) {
          await interaction.reply({ content: "❌ `BASISTRAINING_CHANNEL_ID` staat nog niet ingesteld in `.env` — dat kanaal wordt ook gebruikt voor deze uitnodiging.", ephemeral: true });
          return;
        }
        const channel = (await interaction.guild!.channels.fetch(BASISTRAINING_CHANNEL_ID).catch(() => null)) as TextChannel | null;
        if (!channel) {
          await interaction.reply({ content: "❌ Het ingestelde `BASISTRAINING_CHANNEL_ID` kanaal is niet gevonden.", ephemeral: true });
          return;
        }

        const dag = interaction.options.getString("dag", true);
        const tijd = interaction.options.getString("tijd", true);
        const begeleider1 = interaction.options.getUser("begeleider1", true);
        const begeleider2 = interaction.options.getUser("begeleider2");
        const begeleider3 = interaction.options.getUser("begeleider3");
        const type = interaction.options.getString("type") ?? "Gesprek / Basistraining";
        const duur = interaction.options.getString("duur") ?? "ongeveer 1 uur";

        const begeleiders = [begeleider1, begeleider2, begeleider3].filter(Boolean).map((u) => `${u}`).join(" & ");

        const lines = [
          `Beste <@&${SOLLICITANT_ROLE_ID}>,`,
          "",
          `**${dag} om ${tijd} uur** 🕐 vindt er een *${type}* plaats.`,
          "Zorg dat je op tijd in de wachtkamer aanwezig bent; je wordt vanzelf naar het gesprek gesleept. 🧙",
          "",
          `De training zal worden afgenomen door ${begeleiders}. + mogelijk andere docenten.`,
          "",
          "⚠️ **Belangrijk:**",
          `Wanneer je het gesprek succesvol doorloopt, duurt de volledige training ${duur}.`,
          "",
          "Laat even weten of je erbij bent:",
          "Ja ✅ of Nee ❌",
          "",
          "Als je reageert met een vinkje of kruisje, gaan we ervan uit dat je aanwezig bent of juist niet komt.",
        ];
        if (WACHTKAMER_CHANNEL_ID) lines.push("", `<#${WACHTKAMER_CHANNEL_ID}>`);

        const sentMessage = (await channel.send({ content: lines.join("\n") })) as Message;
        await sentMessage.react("✅").catch(() => {});
        await sentMessage.react("❌").catch(() => {});
        await interaction.reply({ content: `✅ Gesprek gepland en bericht verstuurd in <#${BASISTRAINING_CHANNEL_ID}>!`, ephemeral: true });
      },
    },
  ],
};

export default schedulingModule;
