import {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
  ChannelType,
  Client,
  Events,
  TextChannel,
  Guild,
  AuditLogEvent,
} from "discord.js";
import { BotModule } from "../types";
import { requireStaff } from "../permissions";
import { db } from "../database";

async function getServerLogChannel(guild: Guild): Promise<TextChannel | null> {
  const row = db.prepare("SELECT channel_id FROM server_log_config WHERE guild_id = ?").get(guild.id) as any;
  if (!row?.channel_id) return null;
  const channel = await guild.channels.fetch(row.channel_id).catch(() => null);
  return channel?.isTextBased() ? (channel as TextChannel) : null;
}

async function log(guild: Guild, embed: EmbedBuilder): Promise<void> {
  const channel = await getServerLogChannel(guild);
  if (channel) await channel.send({ embeds: [embed] }).catch(() => {});
}

function truncate(text: string, max = 1000): string {
  if (!text) return "*(leeg)*";
  return text.length > max ? text.slice(0, max) + "…" : text;
}

/** Zoekt de meest recente audit-log entry van dit type voor dit target, zodat we net als
 * Discord's eigen Audit Log kunnen tonen WIE een actie heeft uitgevoerd (gateway-events
 * geven dat namelijk vaak niet mee, alleen de audit log weet dat). */
async function findExecutor(guild: Guild, type: AuditLogEvent, targetId?: string): Promise<string> {
  try {
    const logs = await guild.fetchAuditLogs({ type, limit: 5 });
    const entry = logs.entries.find((e) => !targetId || (e.targetId ?? undefined) === targetId);
    if (entry?.executor) return entry.executor.tag ?? entry.executor.username ?? "Onbekend";
  } catch {
    // Bot heeft mogelijk geen "View Audit Log" permissie — dan laten we het gewoon leeg
  }
  return "Onbekend";
}

const serverlogsModule: BotModule = {
  name: "serverlogs",
  onReady: (client: Client) => {
    // ---------- Berichten ----------
    client.on(Events.MessageDelete, async (message) => {
      if (!message.guild || message.author?.bot) return;
      const embed = new EmbedBuilder()
        .setTitle("🗑️ Bericht verwijderd")
        .setColor(0xed4245)
        .addFields(
          { name: "Auteur", value: message.author ? message.author.tag : "Onbekend", inline: true },
          { name: "Kanaal", value: `<#${message.channelId}>`, inline: true },
          { name: "Inhoud", value: truncate(message.content ?? "") }
        )
        .setTimestamp();
      await log(message.guild, embed);
    });

    client.on(Events.MessageBulkDelete, async (messages, channel) => {
      if (!("guild" in channel) || !channel.guild) return;
      const embed = new EmbedBuilder()
        .setTitle("🧹 Berichten in bulk verwijderd")
        .setColor(0xed4245)
        .addFields(
          { name: "Kanaal", value: `<#${channel.id}>`, inline: true },
          { name: "Aantal", value: String(messages.size), inline: true }
        )
        .setTimestamp();
      await log(channel.guild, embed);
    });

    client.on(Events.MessageUpdate, async (oldMessage, newMessage) => {
      if (!newMessage.guild || newMessage.author?.bot) return;
      if (oldMessage.content === newMessage.content) return; // embeds/reacties triggeren dit ook, alleen echte tekst-edits loggen
      const embed = new EmbedBuilder()
        .setTitle("✏️ Bericht bewerkt")
        .setColor(0xfee75c)
        .addFields(
          { name: "Auteur", value: newMessage.author ? newMessage.author.tag : "Onbekend", inline: true },
          { name: "Kanaal", value: `<#${newMessage.channelId}>`, inline: true },
          { name: "Voor", value: truncate(oldMessage.content ?? "") },
          { name: "Na", value: truncate(newMessage.content ?? "") }
        )
        .setTimestamp();
      await log(newMessage.guild, embed);
    });

    // ---------- Leden ----------
    client.on(Events.GuildMemberAdd, async (member) => {
      const embed = new EmbedBuilder()
        .setTitle("📥 Lid kwam binnen")
        .setColor(0x57f287)
        .addFields(
          { name: "Gebruiker", value: member.user.tag, inline: true },
          { name: "Account aangemaakt", value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true }
        )
        .setThumbnail(member.user.displayAvatarURL())
        .setTimestamp();
      await log(member.guild, embed);
    });

    client.on(Events.GuildMemberRemove, async (member) => {
      const executor = await findExecutor(member.guild, AuditLogEvent.MemberKick, member.id);
      const embed = new EmbedBuilder()
        .setTitle("📤 Lid vertrokken (of gekickt)")
        .setColor(0xe67e22)
        .addFields(
          { name: "Gebruiker", value: member.user.tag, inline: true },
          { name: "Indien gekickt door", value: executor, inline: true }
        )
        .setThumbnail(member.user.displayAvatarURL())
        .setTimestamp();
      await log(member.guild, embed);
    });

    client.on(Events.GuildBanAdd, async (ban) => {
      const executor = await findExecutor(ban.guild, AuditLogEvent.MemberBanAdd, ban.user.id);
      const embed = new EmbedBuilder()
        .setTitle("🔨 Lid verbannen")
        .setColor(0xed4245)
        .addFields(
          { name: "Gebruiker", value: ban.user.tag, inline: true },
          { name: "Door", value: executor, inline: true }
        )
        .setTimestamp();
      await log(ban.guild, embed);
    });

    client.on(Events.GuildBanRemove, async (ban) => {
      const executor = await findExecutor(ban.guild, AuditLogEvent.MemberBanRemove, ban.user.id);
      const embed = new EmbedBuilder()
        .setTitle("✅ Ban opgeheven")
        .setColor(0x57f287)
        .addFields(
          { name: "Gebruiker", value: ban.user.tag, inline: true },
          { name: "Door", value: executor, inline: true }
        )
        .setTimestamp();
      await log(ban.guild, embed);
    });

    client.on(Events.GuildMemberUpdate, async (oldMember, newMember) => {
      const addedRoles = newMember.roles.cache.filter((r) => !oldMember.roles.cache.has(r.id));
      const removedRoles = oldMember.roles.cache.filter((r) => !newMember.roles.cache.has(r.id));
      if (addedRoles.size > 0 || removedRoles.size > 0) {
        const executor = await findExecutor(newMember.guild, AuditLogEvent.MemberRoleUpdate, newMember.id);
        const embed = new EmbedBuilder()
          .setTitle("🎭 Rollen aangepast")
          .setColor(0x5865f2)
          .addFields(
            { name: "Gebruiker", value: newMember.user.tag, inline: true },
            { name: "Door", value: executor, inline: true }
          )
          .setTimestamp();
        if (addedRoles.size > 0) embed.addFields({ name: "Toegevoegd", value: addedRoles.map((r) => r.toString()).join(" "), inline: false });
        if (removedRoles.size > 0) embed.addFields({ name: "Verwijderd", value: removedRoles.map((r) => r.toString()).join(" "), inline: false });
        await log(newMember.guild, embed);
      }

      if (oldMember.nickname !== newMember.nickname) {
        const embed = new EmbedBuilder()
          .setTitle("📝 Bijnaam aangepast")
          .setColor(0x5865f2)
          .addFields(
            { name: "Gebruiker", value: newMember.user.tag, inline: true },
            { name: "Voor", value: oldMember.nickname ?? "*(geen)*", inline: true },
            { name: "Na", value: newMember.nickname ?? "*(geen)*", inline: true }
          )
          .setTimestamp();
        await log(newMember.guild, embed);
      }

      if (oldMember.communicationDisabledUntilTimestamp !== newMember.communicationDisabledUntilTimestamp) {
        const executor = await findExecutor(newMember.guild, AuditLogEvent.MemberUpdate, newMember.id);
        const isNowMuted = !!newMember.communicationDisabledUntilTimestamp && newMember.communicationDisabledUntilTimestamp > Date.now();
        const embed = new EmbedBuilder()
          .setTitle(isNowMuted ? "🔇 Lid getimed-out" : "🔊 Timeout opgeheven")
          .setColor(isNowMuted ? 0x99aab5 : 0x57f287)
          .addFields(
            { name: "Gebruiker", value: newMember.user.tag, inline: true },
            { name: "Door", value: executor, inline: true }
          )
          .setTimestamp();
        if (isNowMuted) {
          embed.addFields({ name: "Tot", value: `<t:${Math.floor(newMember.communicationDisabledUntilTimestamp! / 1000)}:F>`, inline: true });
        }
        await log(newMember.guild, embed);
      }
    });

    // ---------- Kanalen ----------
    client.on(Events.ChannelCreate, async (channel) => {
      if (!channel.guild) return;
      const executor = await findExecutor(channel.guild, AuditLogEvent.ChannelCreate, channel.id);
      const embed = new EmbedBuilder()
        .setTitle("➕ Kanaal aangemaakt")
        .setColor(0x57f287)
        .addFields(
          { name: "Kanaal", value: `${channel.name} (${channel.id})`, inline: true },
          { name: "Door", value: executor, inline: true }
        )
        .setTimestamp();
      await log(channel.guild, embed);
    });

    client.on(Events.ChannelDelete, async (channel) => {
      if (!("guild" in channel) || !channel.guild) return;
      const executor = await findExecutor(channel.guild, AuditLogEvent.ChannelDelete, channel.id);
      const embed = new EmbedBuilder()
        .setTitle("➖ Kanaal verwijderd")
        .setColor(0xed4245)
        .addFields(
          { name: "Kanaal", value: `${(channel as any).name} (${channel.id})`, inline: true },
          { name: "Door", value: executor, inline: true }
        )
        .setTimestamp();
      await log(channel.guild, embed);
    });

    client.on(Events.ChannelUpdate, async (oldChannel, newChannel) => {
      if (!("guild" in newChannel) || !newChannel.guild) return;
      const changes: string[] = [];
      if ("name" in oldChannel && "name" in newChannel && oldChannel.name !== newChannel.name) {
        changes.push(`Naam: **${oldChannel.name}** → **${newChannel.name}**`);
      }
      if ("topic" in oldChannel && "topic" in newChannel && (oldChannel as any).topic !== (newChannel as any).topic) {
        changes.push("Onderwerp/topic aangepast");
      }
      if (changes.length === 0) return; // permissie-only wijzigingen negeren we (te veel ruis)
      const executor = await findExecutor(newChannel.guild, AuditLogEvent.ChannelUpdate, newChannel.id);
      const embed = new EmbedBuilder()
        .setTitle("🔧 Kanaal aangepast")
        .setColor(0x5865f2)
        .addFields(
          { name: "Kanaal", value: `<#${newChannel.id}>`, inline: true },
          { name: "Door", value: executor, inline: true },
          { name: "Wijzigingen", value: changes.join("\n") }
        )
        .setTimestamp();
      await log(newChannel.guild, embed);
    });

    // ---------- Rollen ----------
    client.on(Events.GuildRoleCreate, async (role) => {
      const executor = await findExecutor(role.guild, AuditLogEvent.RoleCreate, role.id);
      const embed = new EmbedBuilder()
        .setTitle("➕ Rol aangemaakt")
        .setColor(0x57f287)
        .addFields(
          { name: "Rol", value: `${role.name} (${role.id})`, inline: true },
          { name: "Door", value: executor, inline: true }
        )
        .setTimestamp();
      await log(role.guild, embed);
    });

    client.on(Events.GuildRoleDelete, async (role) => {
      const executor = await findExecutor(role.guild, AuditLogEvent.RoleDelete, role.id);
      const embed = new EmbedBuilder()
        .setTitle("➖ Rol verwijderd")
        .setColor(0xed4245)
        .addFields(
          { name: "Rol", value: `${role.name} (${role.id})`, inline: true },
          { name: "Door", value: executor, inline: true }
        )
        .setTimestamp();
      await log(role.guild, embed);
    });

    client.on(Events.GuildRoleUpdate, async (oldRole, newRole) => {
      const changes: string[] = [];
      if (oldRole.name !== newRole.name) changes.push(`Naam: **${oldRole.name}** → **${newRole.name}**`);
      if (oldRole.hexColor !== newRole.hexColor) changes.push(`Kleur: \`${oldRole.hexColor}\` → \`${newRole.hexColor}\``);
      if (oldRole.permissions.bitfield !== newRole.permissions.bitfield) changes.push("Permissies aangepast");
      if (changes.length === 0) return;
      const executor = await findExecutor(newRole.guild, AuditLogEvent.RoleUpdate, newRole.id);
      const embed = new EmbedBuilder()
        .setTitle("🔧 Rol aangepast")
        .setColor(0x5865f2)
        .addFields(
          { name: "Rol", value: newRole.toString(), inline: true },
          { name: "Door", value: executor, inline: true },
          { name: "Wijzigingen", value: changes.join("\n") }
        )
        .setTimestamp();
      await log(newRole.guild, embed);
    });

    // ---------- Emoji's ----------
    client.on(Events.GuildEmojiCreate, async (emoji) => {
      if (!emoji.guild) return;
      const executor = await findExecutor(emoji.guild, AuditLogEvent.EmojiCreate, emoji.id);
      const embed = new EmbedBuilder()
        .setTitle("➕ Emoji toegevoegd")
        .setColor(0x57f287)
        .addFields({ name: "Emoji", value: `${emoji.name} (${emoji.id})`, inline: true }, { name: "Door", value: executor, inline: true })
        .setTimestamp();
      await log(emoji.guild, embed);
    });

    client.on(Events.GuildEmojiDelete, async (emoji) => {
      if (!emoji.guild) return;
      const executor = await findExecutor(emoji.guild, AuditLogEvent.EmojiDelete, emoji.id);
      const embed = new EmbedBuilder()
        .setTitle("➖ Emoji verwijderd")
        .setColor(0xed4245)
        .addFields({ name: "Emoji", value: `${emoji.name} (${emoji.id})`, inline: true }, { name: "Door", value: executor, inline: true })
        .setTimestamp();
      await log(emoji.guild, embed);
    });

    // ---------- Uitnodigingen ----------
    client.on(Events.InviteCreate, async (invite) => {
      if (!invite.guild) return;
      const embed = new EmbedBuilder()
        .setTitle("🔗 Uitnodiging aangemaakt")
        .setColor(0x57f287)
        .addFields(
          { name: "Code", value: invite.code, inline: true },
          { name: "Door", value: invite.inviter?.tag ?? "Onbekend", inline: true },
          { name: "Kanaal", value: invite.channel ? `<#${invite.channel.id}>` : "Onbekend", inline: true }
        )
        .setTimestamp();
      await log(invite.guild as Guild, embed);
    });

    client.on(Events.InviteDelete, async (invite) => {
      if (!invite.guild) return;
      const embed = new EmbedBuilder()
        .setTitle("🗑️ Uitnodiging verwijderd/verlopen")
        .setColor(0xed4245)
        .addFields({ name: "Code", value: invite.code, inline: true })
        .setTimestamp();
      await log(invite.guild as Guild, embed);
    });

    // ---------- Webhooks ----------
    client.on(Events.WebhooksUpdate, async (channel) => {
      const embed = new EmbedBuilder()
        .setTitle("🪝 Webhook gewijzigd")
        .setColor(0x5865f2)
        .addFields({ name: "Kanaal", value: `<#${channel.id}>` })
        .setTimestamp();
      await log(channel.guild, embed);
    });

    // ---------- Threads ----------
    client.on(Events.ThreadCreate, async (thread) => {
      const embed = new EmbedBuilder()
        .setTitle("🧵 Thread aangemaakt")
        .setColor(0x57f287)
        .addFields({ name: "Thread", value: `${thread.name} (<#${thread.id}>)` })
        .setTimestamp();
      await log(thread.guild, embed);
    });

    client.on(Events.ThreadDelete, async (thread) => {
      const embed = new EmbedBuilder()
        .setTitle("🧵 Thread verwijderd")
        .setColor(0xed4245)
        .addFields({ name: "Thread", value: thread.name })
        .setTimestamp();
      await log(thread.guild, embed);
    });

    // ---------- Voice ----------
    client.on(Events.VoiceStateUpdate, async (oldState, newState) => {
      const member = newState.member ?? oldState.member;
      if (!member || !newState.guild) return;

      if (!oldState.channelId && newState.channelId) {
        const embed = new EmbedBuilder()
          .setTitle("🔊 Voicekanaal gejoined")
          .setColor(0x57f287)
          .addFields({ name: "Gebruiker", value: member.user.tag, inline: true }, { name: "Kanaal", value: `<#${newState.channelId}>`, inline: true })
          .setTimestamp();
        await log(newState.guild, embed);
      } else if (oldState.channelId && !newState.channelId) {
        const embed = new EmbedBuilder()
          .setTitle("🔇 Voicekanaal verlaten")
          .setColor(0xe67e22)
          .addFields({ name: "Gebruiker", value: member.user.tag, inline: true }, { name: "Kanaal", value: `<#${oldState.channelId}>`, inline: true })
          .setTimestamp();
        await log(newState.guild, embed);
      } else if (oldState.channelId && newState.channelId && oldState.channelId !== newState.channelId) {
        const embed = new EmbedBuilder()
          .setTitle("🔀 Voicekanaal gewisseld")
          .setColor(0x5865f2)
          .addFields(
            { name: "Gebruiker", value: member.user.tag, inline: true },
            { name: "Van", value: `<#${oldState.channelId}>`, inline: true },
            { name: "Naar", value: `<#${newState.channelId}>`, inline: true }
          )
          .setTimestamp();
        await log(newState.guild, embed);
      }
    });

    // ---------- Server-instellingen ----------
    client.on(Events.GuildUpdate, async (oldGuild, newGuild) => {
      const changes: string[] = [];
      if (oldGuild.name !== newGuild.name) changes.push(`Naam: **${oldGuild.name}** → **${newGuild.name}**`);
      if (oldGuild.iconURL() !== newGuild.iconURL()) changes.push("Server-icoon aangepast");
      if (changes.length === 0) return;
      const executor = await findExecutor(newGuild, AuditLogEvent.GuildUpdate);
      const embed = new EmbedBuilder()
        .setTitle("⚙️ Serverinstellingen aangepast")
        .setColor(0x5865f2)
        .addFields({ name: "Door", value: executor, inline: true }, { name: "Wijzigingen", value: changes.join("\n") })
        .setTimestamp();
      await log(newGuild, embed);
    });

    // ---------- AutoMod ----------
    client.on(Events.AutoModerationRuleCreate, async (rule) => {
      const embed = new EmbedBuilder()
        .setTitle("🛡️ AutoMod-regel aangemaakt")
        .setColor(0x57f287)
        .addFields({ name: "Regel", value: rule.name })
        .setTimestamp();
      await log(rule.guild, embed);
    });

    client.on(Events.AutoModerationRuleDelete, async (rule) => {
      const embed = new EmbedBuilder()
        .setTitle("🛡️ AutoMod-regel verwijderd")
        .setColor(0xed4245)
        .addFields({ name: "Regel", value: rule.name })
        .setTimestamp();
      await log(rule.guild, embed);
    });

    client.on(Events.AutoModerationActionExecution, async (execution) => {
      const embed = new EmbedBuilder()
        .setTitle("🛡️ AutoMod-actie uitgevoerd")
        .setColor(0xfee75c)
        .addFields(
          { name: "Gebruiker", value: `<@${execution.userId}>`, inline: true },
          { name: "Kanaal", value: execution.channelId ? `<#${execution.channelId}>` : "Onbekend", inline: true },
          { name: "Inhoud", value: truncate(execution.content ?? "") }
        )
        .setTimestamp();
      await log(execution.guild, embed);
    });
  },
  commands: [
    {
      data: new SlashCommandBuilder()
        .setName("setserverlogchannel")
        .setDescription("Stel het kanaal in voor uitgebreide server logs (net als Discord's eigen Audit Log).")
        .addChannelOption((opt) =>
          opt.setName("channel").setDescription("Het log-kanaal").addChannelTypes(ChannelType.GuildText).setRequired(true)
        ),
      execute: async (interaction) => {
        if (!(await requireStaff(interaction))) return;
        const channel = interaction.options.getChannel("channel", true);
        db.prepare(
          `INSERT INTO server_log_config (guild_id, channel_id) VALUES (?, ?)
           ON CONFLICT(guild_id) DO UPDATE SET channel_id = excluded.channel_id`
        ).run(interaction.guildId, channel.id);
        await interaction.reply({
          content:
            `✅ Uitgebreide server logs gaan voortaan naar <#${channel.id}>. Dit dekt: berichten ` +
            `(bewerkt/verwijderd/bulk-verwijderd), leden (join/leave/kick/ban/rollen/bijnaam/timeout), ` +
            `kanalen (aanmaken/verwijderen/aanpassen), rollen (aanmaken/verwijderen/aanpassen), emoji's, ` +
            `uitnodigingen, webhooks, threads, voicekanalen (join/leave/wissel), serverinstellingen en AutoMod.\n\n` +
            `⚠️ Voor "Door: ..." (wie de actie uitvoerde) heeft de bot de **"Audit-logboek weergeven"**-permissie nodig.`,
          ephemeral: true,
        });
      },
    },
  ],
};

export default serverlogsModule;
