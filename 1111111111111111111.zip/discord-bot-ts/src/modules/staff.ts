import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, PermissionsBitField, Role } from "discord.js";
import { BotModule } from "../types";
import { db } from "../database";
import { STAFF_ROLE_IDS, OWNER_ID } from "../config";

const staffModule: BotModule = {
  name: "staff",
  commands: [
    {
      data: new SlashCommandBuilder()
        .setName("addstaffrole")
        .setDescription("Geef een rol toegang tot bot-configuratiecommands (zonder Administrator-rechten).")
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addRoleOption((opt) => opt.setName("role").setDescription("De rol (kies via de lijst)"))
        .addStringOption((opt) => opt.setName("role_id").setDescription("Of vul hier direct een rol-ID in")),
      execute: async (interaction) => {
        const role = interaction.options.getRole("role");
        const roleIdInput = interaction.options.getString("role_id");
        const roleId = role?.id ?? roleIdInput;

        if (!roleId) {
          await interaction.reply({ content: "❌ Geef óf `role` óf `role_id` op.", ephemeral: true });
          return;
        }
        if (!/^\d{15,25}$/.test(roleId)) {
          await interaction.reply({ content: "❌ Dat lijkt geen geldig rol-ID.", ephemeral: true });
          return;
        }

        db.prepare("INSERT OR IGNORE INTO staff_roles (guild_id, role_id) VALUES (?, ?)").run(interaction.guildId, roleId);
        await interaction.reply({
          content: `✅ Leden met <@&${roleId}> kunnen nu bot-configuratiecommands gebruiken (bv. \`/setlogchannel\`, \`/ticketsetup\`, enz.) zonder Administrator-rechten nodig te hebben.`,
          ephemeral: true,
        });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("removestaffrole")
        .setDescription("Haal staff-toegang bij een rol weg.")
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addRoleOption((opt) => opt.setName("role").setDescription("De rol (kies via de lijst)"))
        .addStringOption((opt) => opt.setName("role_id").setDescription("Of vul hier direct een rol-ID in")),
      execute: async (interaction) => {
        const role = interaction.options.getRole("role");
        const roleIdInput = interaction.options.getString("role_id");
        const roleId = role?.id ?? roleIdInput;

        if (!roleId) {
          await interaction.reply({ content: "❌ Geef óf `role` óf `role_id` op.", ephemeral: true });
          return;
        }

        const result = db.prepare("DELETE FROM staff_roles WHERE guild_id = ? AND role_id = ?").run(interaction.guildId, roleId);
        if (result.changes === 0) {
          await interaction.reply({ content: "❌ Deze rol stond niet in de staff-lijst.", ephemeral: true });
        } else {
          await interaction.reply({ content: `🗑️ <@&${roleId}> heeft geen staff-toegang meer.`, ephemeral: true });
        }
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("liststaffroles")
        .setDescription("Toon welke rollen bot-configuratiecommands mogen gebruiken.")
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
      execute: async (interaction) => {
        const rows = db.prepare("SELECT role_id FROM staff_roles WHERE guild_id = ?").all(interaction.guildId) as Array<{ role_id: string }>;
        const embed = new EmbedBuilder().setTitle("🛡️ Staff-rollen").setColor(0x5865f2);

        if (STAFF_ROLE_IDS.length > 0) {
          embed.addFields({ name: "Vast ingesteld via .env (STAFF_ROLE_IDS)", value: STAFF_ROLE_IDS.map((id) => `<@&${id}>`).join("\n") });
        }
        embed.addFields({
          name: "Toegevoegd via /addstaffrole",
          value: rows.length ? rows.map((r) => `<@&${r.role_id}>`).join("\n") : "*(nog geen)*",
        });
        embed.setFooter({ text: "Leden met Discord's eigen Administrator-permissie mogen dit altijd, ook als ze hier niet in staan." });
        await interaction.reply({ embeds: [embed], ephemeral: true });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("grantadmin")
        .setDescription("Geef een rol alle permissies behalve Server Beheren (alleen bruikbaar door de bot-eigenaar).")
        .addRoleOption((opt) => opt.setName("rol").setDescription("De rol die de permissies krijgt").setRequired(true)),
      execute: async (interaction) => {
        if (!OWNER_ID || interaction.user.id !== OWNER_ID) {
          // Bewust een generieke melding, geen uitleg dat dit command specifiek voor de eigenaar is.
          await interaction.reply({ content: "❌ Je hebt geen rechten om dit command te gebruiken.", ephemeral: true });
          return;
        }

        const rol = interaction.options.getRole("rol", true) as Role;
        const botMember = interaction.guild!.members.me!;

        if (rol.position >= botMember.roles.highest.position) {
          await interaction.reply({
            content: `❌ De rol van de bot staat niet boven **${rol.name}** in de rollenlijst. Sleep de bot-rol in Serverinstellingen → Rollen boven **${rol.name}**, en probeer het opnieuw.`,
            ephemeral: true,
          });
          return;
        }

        // Alle permissies aanzetten, behalve "Manage Server" (Server Beheren). Let op: de
        // Administrator-vlag moet hiervoor OOK weg, want die overrulet Discord's individuele
        // permissie-checks (dus zolang Administrator aan staat, werkt Server Beheren alsnog
        // ongeacht of die losse vlag verwijderd is).
        const alleBehalveServerBeheren = new PermissionsBitField(PermissionsBitField.All)
          .remove(PermissionFlagsBits.ManageGuild)
          .remove(PermissionFlagsBits.Administrator);

        try {
          await rol.setPermissions(alleBehalveServerBeheren, `Permissies (behalve Server Beheren) toegekend door bot-eigenaar (${interaction.user.tag})`);
        } catch {
          await interaction.reply({ content: "❌ De bot heeft zelf niet de 'Rollen beheren'-permissie.", ephemeral: true });
          return;
        }

        await interaction.reply({ content: `✅ **${rol.name}** heeft nu alle permissies, behalve **Server Beheren**.`, ephemeral: true });
      },
    },
  ],
};

export default staffModule;
