import {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
  ChannelType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ButtonInteraction,
  StringSelectMenuInteraction,
  ModalSubmitInteraction,
  Guild,
  TextChannel,
  CategoryChannel,
  Role,
  OverwriteResolvable,
  AttachmentBuilder,
  User,
} from "discord.js";
import { BotModule } from "../types";
import { requireStaff, isStaff } from "../permissions";
import { db } from "../database";

const CLOSE_BUTTON_ID = "ticket_close_button";
const DELETE_BUTTON_ID = "ticket_delete_button";
const SELECT_MENU_ID = "ticket_type_select";
const MODAL_PREFIX = "ticket_modal_";

// ---------- Helpers ----------

function getTicketTypes(guildId: string): any[] {
  return db.prepare("SELECT * FROM ticket_types WHERE guild_id = ? ORDER BY id").all(guildId) as any[];
}

function getTicketQuestions(ticketTypeId: number): any[] {
  return db.prepare("SELECT * FROM ticket_questions WHERE ticket_type_id = ? ORDER BY position").all(ticketTypeId) as any[];
}

async function getLogChannel(guild: Guild): Promise<TextChannel | null> {
  const row = db.prepare("SELECT log_channel_id FROM ticket_config WHERE guild_id = ?").get(guild.id) as any;
  if (!row?.log_channel_id) return null;
  const channel = await guild.channels.fetch(row.log_channel_id).catch(() => null);
  return channel?.isTextBased() ? (channel as TextChannel) : null;
}

async function getArchiveCategory(guild: Guild): Promise<CategoryChannel | null> {
  const row = db.prepare("SELECT archive_category_id FROM ticket_config WHERE guild_id = ?").get(guild.id) as any;
  if (!row?.archive_category_id) return null;
  const channel = await guild.channels.fetch(row.archive_category_id).catch(() => null);
  return channel?.type === ChannelType.GuildCategory ? (channel as CategoryChannel) : null;
}

/** Bouwt een simpele tekst-transcript van (tot 200) berichten in het kanaal, oud naar nieuw. */
async function generateTranscript(channel: TextChannel): Promise<AttachmentBuilder> {
  const messages = await channel.messages.fetch({ limit: 100 });
  const sorted = [...messages.values()].sort((a, b) => a.createdTimestamp - b.createdTimestamp);

  const lines = sorted.map((m) => {
    const time = new Date(m.createdTimestamp).toISOString().replace("T", " ").slice(0, 19);
    const content = m.content || (m.embeds.length ? "[embed]" : m.attachments.size ? "[bijlage]" : "");
    return `[${time}] ${m.author.tag}: ${content}`;
  });

  const text = `Transcript van #${channel.name}\nGegenereerd op ${new Date().toISOString()}\n\n${lines.join("\n")}`;
  return new AttachmentBuilder(Buffer.from(text, "utf-8"), { name: `transcript-${channel.name}.txt` });
}

function buildDeleteButtonRow(): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(DELETE_BUTTON_ID).setLabel("Verwijder ticket").setStyle(ButtonStyle.Danger).setEmoji("🗑️")
  );
}

/**
 * Gedeelde sluitlogica voor zowel de knop als /closeticket:
 * - stuurt de transcript naar het logkanaal
 * - als er een archiefcategorie is ingesteld: verplaatst het kanaal daarheen, ontneemt de
 *   ticket-opener/supportrol de toegang (alleen staff met beheerdersrechten ziet 'm nog),
 *   en zet er een "Verwijder ticket"-knop bij zodat een admin 'm later kan opruimen.
 * - anders: valt terug op het oude gedrag (kanaal na 5 seconden verwijderen).
 */
async function closeTicket(channel: TextChannel, closedBy: User, ticket: any | undefined): Promise<void> {
  const guild = channel.guild;

  if (ticket) {
    db.prepare("UPDATE tickets SET status = 'closed', closed_at = CURRENT_TIMESTAMP WHERE id = ?").run(ticket.id);
  }

  const transcript = await generateTranscript(channel).catch(() => null);

  const logChannel = await getLogChannel(guild);
  if (logChannel) {
    const embed = new EmbedBuilder()
      .setTitle("🔒 Ticket gesloten")
      .setColor(0x992d22)
      .addFields(
        { name: "Kanaal", value: channel.name, inline: true },
        { name: "Gesloten door", value: closedBy.tag, inline: true }
      );
    if (ticket) {
      embed.addFields(
        { name: "Type", value: ticket.ticket_type_label || "onbekend", inline: true },
        { name: "Geopend door", value: `<@${ticket.user_id}>`, inline: true }
      );
    }
    await logChannel.send({ embeds: [embed], files: transcript ? [transcript] : [] }).catch(() => {});
  }

  const archiveCategory = await getArchiveCategory(guild);
  if (archiveCategory) {
    // Alleen staff (beheerders) mag het gearchiveerde ticket nog zien; opener + supportrol worden eraf gehaald.
    const overwrites: OverwriteResolvable[] = [
      { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
      { id: guild.members.me!.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
    ];
    await channel.edit({ parent: archiveCategory.id, permissionOverwrites: overwrites, lockPermissions: false }).catch(() => {});
    await channel.send({
      content: "🔒 Dit ticket is gesloten en gearchiveerd. Alleen staff met beheerdersrechten kan dit nog zien.",
      components: [buildDeleteButtonRow()],
    }).catch(() => {});
  } else {
    await channel.send("🔒 Ticket wordt gesloten in 5 seconden...").catch(() => {});
    setTimeout(() => {
      channel.delete(`Ticket gesloten door ${closedBy.tag}`).catch(() => {});
    }, 5000);
  }
}

function buildCloseButtonRow(): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(CLOSE_BUTTON_ID).setLabel("Sluit ticket").setStyle(ButtonStyle.Danger).setEmoji("🔒")
  );
}

function buildSelectMenu(types: any[]): ActionRowBuilder<StringSelectMenuBuilder> {
  const menu = new StringSelectMenuBuilder()
    .setCustomId(SELECT_MENU_ID)
    .setPlaceholder("Kies het soort ticket dat je wilt openen...")
    .addOptions(
      types.map((t) => ({
        label: t.label,
        value: String(t.id),
        description: t.description ? String(t.description).slice(0, 100) : undefined,
        emoji: t.emoji || undefined,
      }))
    );
  return new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu);
}

async function createTicketChannel(
  interaction: StringSelectMenuInteraction | ModalSubmitInteraction,
  ticketType: any,
  answers: Array<[string, string]> | null
): Promise<void> {
  const guild = interaction.guild!;
  const member = interaction.member as any;
  const category = (await guild.channels.fetch(ticketType.category_id).catch(() => null)) as CategoryChannel | null;
  const supportRole = guild.roles.cache.get(ticketType.support_role_id) as Role | undefined;

  const overwrites: OverwriteResolvable[] = [
    { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
    {
      id: interaction.user.id,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
    },
    { id: guild.members.me!.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
  ];
  if (supportRole) {
    overwrites.push({ id: supportRole.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] });
  }

  const channelName = `${ticketType.label}-${interaction.user.username}`.toLowerCase().replace(/\s+/g, "-").slice(0, 90);
  const ticketChannel = await guild.channels.create({
    name: channelName,
    type: ChannelType.GuildText,
    parent: category?.id,
    permissionOverwrites: overwrites,
    reason: `Ticket (${ticketType.label}) geopend door ${interaction.user.tag}`,
  });

  db.prepare(
    "INSERT INTO tickets (guild_id, channel_id, user_id, ticket_type_label, status) VALUES (?, ?, ?, ?, 'open')"
  ).run(guild.id, ticketChannel.id, interaction.user.id, ticketType.label);

  const embed = new EmbedBuilder()
    .setTitle(`${ticketType.emoji || "🎫"} ${ticketType.label}`)
    .setDescription(
      ticketType.description || `Welkom ${interaction.user}! Beschrijf je vraag, het supportteam helpt je zo snel mogelijk.`
    )
    .setColor(0x5865f2);

  if (answers) {
    for (const [question, answer] of answers) {
      embed.addFields({ name: question, value: answer || "*(geen antwoord)*" });
    }
  }

  await ticketChannel.send({
    content: `${interaction.user} ${supportRole ? supportRole.toString() : ""}`,
    embeds: [embed],
    components: [buildCloseButtonRow()],
  });

  await interaction.reply({ content: `✅ Ticket aangemaakt: ${ticketChannel}`, ephemeral: true });
}

// ---------- Interactie-afhandeling ----------

async function handleSelectMenu(interaction: StringSelectMenuInteraction): Promise<boolean> {
  if (interaction.customId !== SELECT_MENU_ID) return false;

  const typeId = Number(interaction.values[0]);
  const ticketType = db
    .prepare("SELECT * FROM ticket_types WHERE id = ? AND guild_id = ?")
    .get(typeId, interaction.guildId) as any;

  if (!ticketType) {
    await interaction.reply({ content: "❌ Dit ticket-type bestaat niet meer. Vraag een admin om het paneel opnieuw te plaatsen.", ephemeral: true });
    return true;
  }

  const existing = db
    .prepare("SELECT * FROM tickets WHERE guild_id = ? AND user_id = ? AND status = 'open' AND ticket_type_label = ?")
    .get(interaction.guildId, interaction.user.id, ticketType.label) as any;
  if (existing) {
    const channelStillExists = interaction.guild!.channels.cache.has(existing.channel_id);
    if (channelStillExists) {
      await interaction.reply({ content: `Je hebt al een open ticket van dit type: <#${existing.channel_id}>`, ephemeral: true });
      return true;
    }
  }

  const questions = getTicketQuestions(ticketType.id);
  if (questions.length > 0) {
    const modal = new ModalBuilder().setCustomId(`${MODAL_PREFIX}${ticketType.id}`).setTitle(ticketType.label.slice(0, 45));
    for (const q of questions.slice(0, 5)) {
      const input = new TextInputBuilder()
        .setCustomId(`q_${q.id}`)
        .setLabel(String(q.question).slice(0, 45))
        .setStyle(q.style === "paragraph" ? TextInputStyle.Paragraph : TextInputStyle.Short)
        .setRequired(!!q.required)
        .setMaxLength(q.style === "paragraph" ? 1000 : 300);
      modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(input));
    }
    await interaction.showModal(modal);
  } else {
    await createTicketChannel(interaction, ticketType, null);
  }
  return true;
}

async function handleModalSubmit(interaction: ModalSubmitInteraction): Promise<boolean> {
  if (!interaction.customId.startsWith(MODAL_PREFIX)) return false;

  const typeId = Number(interaction.customId.slice(MODAL_PREFIX.length));
  const ticketType = db.prepare("SELECT * FROM ticket_types WHERE id = ? AND guild_id = ?").get(typeId, interaction.guildId) as any;
  if (!ticketType) {
    await interaction.reply({ content: "❌ Dit ticket-type bestaat niet meer.", ephemeral: true });
    return true;
  }

  const questions = getTicketQuestions(ticketType.id);
  const answers: Array<[string, string]> = questions.slice(0, 5).map((q) => [q.question, interaction.fields.getTextInputValue(`q_${q.id}`)]);

  await createTicketChannel(interaction, ticketType, answers);
  return true;
}

async function handleButton(interaction: ButtonInteraction): Promise<boolean> {
  if (interaction.customId === CLOSE_BUTTON_ID) {
    const ticket = db
      .prepare("SELECT * FROM tickets WHERE guild_id = ? AND channel_id = ?")
      .get(interaction.guildId, interaction.channelId) as any;

    await interaction.reply("🔒 Bezig met sluiten (transcript wordt opgeslagen)...");
    await closeTicket(interaction.channel as TextChannel, interaction.user, ticket);
    return true;
  }

  if (interaction.customId === DELETE_BUTTON_ID) {
    const isAdmin = isStaff(interaction);
    if (!isAdmin) {
      await interaction.reply({ content: "❌ Alleen staff (of Administrator) kan een gearchiveerd ticket verwijderen. Zie `/addstaffrole`.", ephemeral: true });
      return true;
    }
    await interaction.reply("🗑️ Ticket wordt definitief verwijderd...");
    setTimeout(() => {
      (interaction.channel as TextChannel).delete(`Ticket verwijderd door ${interaction.user.tag}`).catch(() => {});
    }, 2000);
    return true;
  }

  return false;
}

// ---------- Module ----------

const ticketsModule: BotModule = {
  name: "tickets",
  handleButton,
  handleSelectMenu,
  handleModalSubmit,
  commands: [
    {
      data: new SlashCommandBuilder()
        .setName("addtickettype")
        .setDescription("Voeg een ticket-type toe aan de dropdown.")
        .addStringOption((opt) => opt.setName("label").setDescription("Naam die in de dropdown komt te staan").setRequired(true))
        .addChannelOption((opt) =>
          opt.setName("category").setDescription("Categorie voor dit type").addChannelTypes(ChannelType.GuildCategory).setRequired(true)
        )
        .addRoleOption((opt) => opt.setName("support_role").setDescription("Rol die dit type mag zien en beantwoorden").setRequired(true))
        .addStringOption((opt) => opt.setName("emoji").setDescription("Emoji voor in de dropdown (optioneel)"))
        .addStringOption((opt) => opt.setName("description").setDescription("Tekst in het ticketkanaal (optioneel)")),
      execute: async (interaction) => {
        if (!(await requireStaff(interaction))) return;
        const label = interaction.options.getString("label", true);
        const category = interaction.options.getChannel("category", true);
        const supportRole = interaction.options.getRole("support_role", true);
        const emoji = interaction.options.getString("emoji");
        const description = interaction.options.getString("description");

        const { c: count } = db
          .prepare("SELECT COUNT(*) as c FROM ticket_types WHERE guild_id = ?")
          .get(interaction.guildId) as { c: number };
        if (count >= 25) {
          await interaction.reply({ content: "❌ Je hebt al 25 ticket-types (het maximum voor een dropdown).", ephemeral: true });
          return;
        }

        db.prepare(
          "INSERT INTO ticket_types (guild_id, label, emoji, description, category_id, support_role_id) VALUES (?, ?, ?, ?, ?, ?)"
        ).run(interaction.guildId, label, emoji, description, category.id, supportRole.id);

        await interaction.reply({
          content: `✅ Ticket-type **${label}** toegevoegd → categorie **${category.name}**, supportrol <@&${supportRole.id}>.\nGebruik \`/ticketpanel\` om het paneel (opnieuw) te plaatsen.`,
          ephemeral: true,
        });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("removetickettype")
        .setDescription("Verwijder een ticket-type uit de dropdown.")
        .addStringOption((opt) => opt.setName("label").setDescription("Exacte naam van het te verwijderen type").setRequired(true)),
      execute: async (interaction) => {
        if (!(await requireStaff(interaction))) return;
        const label = interaction.options.getString("label", true);
        const result = db.prepare("DELETE FROM ticket_types WHERE guild_id = ? AND label = ?").run(interaction.guildId, label);
        if (result.changes === 0) {
          await interaction.reply({ content: `❌ Geen ticket-type gevonden met naam '${label}'.`, ephemeral: true });
        } else {
          await interaction.reply({ content: `🗑️ Ticket-type **${label}** verwijderd. Gebruik \`/ticketpanel\` om het paneel opnieuw te plaatsen.`, ephemeral: true });
        }
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("listtickettypes")
        .setDescription("Toon alle ingestelde ticket-types."),
      execute: async (interaction) => {
        if (!(await requireStaff(interaction))) return;
        const types = getTicketTypes(interaction.guildId!);
        if (types.length === 0) {
          await interaction.reply({ content: "Nog geen ticket-types ingesteld. Gebruik `/addtickettype`.", ephemeral: true });
          return;
        }
        const embed = new EmbedBuilder().setTitle("🎫 Ticket-types").setColor(0x5865f2);
        for (const t of types) {
          const category = interaction.guild!.channels.cache.get(t.category_id);
          embed.addFields({
            name: `${t.emoji || "🎫"} ${t.label}`,
            value: `Categorie: ${category ? category.name : "⚠️ verwijderd"}\nSupportrol: <@&${t.support_role_id}>`,
          });
        }
        await interaction.reply({ embeds: [embed], ephemeral: true });
      },
    },

    // ---------- Formuliervragen ----------
    {
      data: new SlashCommandBuilder()
        .setName("addtickettypequestion")
        .setDescription("Voeg een vraag toe die getoond wordt voordat dit ticket-type wordt aangemaakt.")
        .addStringOption((opt) => opt.setName("label").setDescription("Naam van het ticket-type").setRequired(true))
        .addStringOption((opt) => opt.setName("question").setDescription("De vraag").setRequired(true))
        .addBooleanOption((opt) => opt.setName("required").setDescription("Verplicht? (standaard: ja)"))
        .addStringOption((opt) =>
          opt.setName("answer_type").setDescription("Kort of lang antwoord").addChoices({ name: "Kort antwoord", value: "short" }, { name: "Lang antwoord", value: "paragraph" })
        ),
      execute: async (interaction) => {
        if (!(await requireStaff(interaction))) return;
        const label = interaction.options.getString("label", true);
        const question = interaction.options.getString("question", true);
        const required = interaction.options.getBoolean("required") ?? true;
        const style = interaction.options.getString("answer_type") ?? "short";

        const ticketType = db.prepare("SELECT * FROM ticket_types WHERE guild_id = ? AND label = ?").get(interaction.guildId, label) as any;
        if (!ticketType) {
          await interaction.reply({ content: `❌ Geen ticket-type gevonden met naam '${label}'. Maak deze eerst met \`/addtickettype\`.`, ephemeral: true });
          return;
        }

        const existingQuestions = getTicketQuestions(ticketType.id);
        if (existingQuestions.length >= 5) {
          await interaction.reply({ content: "❌ Dit type heeft al 5 vragen (het maximum voor een Discord-formulier). Verwijder er eerst één met `/removetickettypequestion`.", ephemeral: true });
          return;
        }

        db.prepare(
          "INSERT INTO ticket_questions (ticket_type_id, question, style, required, position) VALUES (?, ?, ?, ?, ?)"
        ).run(ticketType.id, question, style, required ? 1 : 0, existingQuestions.length);

        await interaction.reply({
          content: `✅ Vraag toegevoegd aan **${label}** (${existingQuestions.length + 1}/5): "${question}"\nGebruikers krijgen nu een formulier te zien voordat dit ticket wordt aangemaakt.`,
          ephemeral: true,
        });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("removetickettypequestion")
        .setDescription("Verwijder een vraag van een ticket-type.")
        .addStringOption((opt) => opt.setName("label").setDescription("Naam van het ticket-type").setRequired(true))
        .addIntegerOption((opt) => opt.setName("number").setDescription("Volgnummer van de vraag").setMinValue(1).setRequired(true)),
      execute: async (interaction) => {
        if (!(await requireStaff(interaction))) return;
        const label = interaction.options.getString("label", true);
        const number = interaction.options.getInteger("number", true);

        const ticketType = db.prepare("SELECT * FROM ticket_types WHERE guild_id = ? AND label = ?").get(interaction.guildId, label) as any;
        if (!ticketType) {
          await interaction.reply({ content: `❌ Geen ticket-type gevonden met naam '${label}'.`, ephemeral: true });
          return;
        }

        const questions = getTicketQuestions(ticketType.id);
        if (number < 1 || number > questions.length) {
          await interaction.reply({ content: `❌ Ongeldig volgnummer. Dit type heeft ${questions.length} vraag/vragen.`, ephemeral: true });
          return;
        }

        const toDelete = questions[number - 1];
        db.prepare("DELETE FROM ticket_questions WHERE id = ?").run(toDelete.id);
        const remaining = getTicketQuestions(ticketType.id);
        remaining.forEach((q, i) => db.prepare("UPDATE ticket_questions SET position = ? WHERE id = ?").run(i, q.id));

        await interaction.reply({ content: `🗑️ Vraag "${toDelete.question}" verwijderd van **${label}**.`, ephemeral: true });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("listtickettypequestions")
        .setDescription("Toon de formuliervragen van een ticket-type.")
        .addStringOption((opt) => opt.setName("label").setDescription("Naam van het ticket-type").setRequired(true)),
      execute: async (interaction) => {
        if (!(await requireStaff(interaction))) return;
        const label = interaction.options.getString("label", true);
        const ticketType = db.prepare("SELECT * FROM ticket_types WHERE guild_id = ? AND label = ?").get(interaction.guildId, label) as any;
        if (!ticketType) {
          await interaction.reply({ content: `❌ Geen ticket-type gevonden met naam '${label}'.`, ephemeral: true });
          return;
        }
        const questions = getTicketQuestions(ticketType.id);
        if (questions.length === 0) {
          await interaction.reply({ content: `**${label}** heeft nog geen formuliervragen. Voeg ze toe met \`/addtickettypequestion\`.`, ephemeral: true });
          return;
        }
        const embed = new EmbedBuilder().setTitle(`📝 Formuliervragen — ${label}`).setColor(0x5865f2);
        questions.forEach((q, i) => {
          const stijl = q.style === "paragraph" ? "Lang antwoord" : "Kort antwoord";
          const verplicht = q.required ? "verplicht" : "optioneel";
          embed.addFields({ name: `${i + 1}. ${q.question}`, value: `${stijl}, ${verplicht}` });
        });
        await interaction.reply({ embeds: [embed], ephemeral: true });
      },
    },

    // ---------- Algemene ticket-config ----------
    {
      data: new SlashCommandBuilder()
        .setName("ticketsetup")
        .setDescription("Stel het logkanaal (en optioneel archief) voor tickets in.")
        .addChannelOption((opt) =>
          opt.setName("log_channel").setDescription("Kanaal voor ticketlogs (incl. transcript)").addChannelTypes(ChannelType.GuildText).setRequired(true)
        )
        .addChannelOption((opt) =>
          opt
            .setName("archive_category")
            .setDescription("Categorie waar gesloten tickets heen verplaatst worden (optioneel, i.p.v. direct verwijderen)")
            .addChannelTypes(ChannelType.GuildCategory)
        ),
      execute: async (interaction) => {
        if (!(await requireStaff(interaction))) return;
        const logChannel = interaction.options.getChannel("log_channel", true);
        const archiveCategory = interaction.options.getChannel("archive_category");
        db.prepare(
          `INSERT INTO ticket_config (guild_id, log_channel_id, archive_category_id) VALUES (?, ?, ?)
           ON CONFLICT(guild_id) DO UPDATE SET log_channel_id = excluded.log_channel_id, archive_category_id = excluded.archive_category_id`
        ).run(interaction.guildId, logChannel.id, archiveCategory?.id ?? null);
        const archiveText = archiveCategory
          ? `Gesloten tickets worden verplaatst naar **${archiveCategory.name}** (alleen zichtbaar voor beheerders) i.p.v. direct verwijderd.`
          : "Geen archiefcategorie ingesteld: gesloten tickets worden direct verwijderd (na 5 sec).";
        await interaction.reply({
          content: `✅ Ticketlogkanaal ingesteld op <#${logChannel.id}>.\n${archiveText}\nVoeg nu ticket-types toe met \`/addtickettype\` en plaats daarna \`/ticketpanel\`.`,
          ephemeral: true,
        });
      },
    },
    {
      data: new SlashCommandBuilder()
        .setName("ticketpanel")
        .setDescription("Plaats het ticket-paneel (dropdown) in dit kanaal.")
        .addStringOption((opt) => opt.setName("message").setDescription("Tekst boven de dropdown (optioneel)")),
      execute: async (interaction) => {
        if (!(await requireStaff(interaction))) return;
        const types = getTicketTypes(interaction.guildId!);
        if (types.length === 0) {
          await interaction.reply({ content: "❌ Voeg eerst ticket-types toe met `/addtickettype`.", ephemeral: true });
          return;
        }
        const message = interaction.options.getString("message");
        const embed = new EmbedBuilder()
          .setTitle("🎫 Support Tickets")
          .setDescription(message || "Kies hieronder het soort ticket dat je wilt openen. Ons team helpt je zo snel mogelijk verder.")
          .setColor(0x5865f2);

        const channel = interaction.channel as TextChannel;
        await channel.send({ embeds: [embed], components: [buildSelectMenu(types)] });
        await interaction.reply({ content: "✅ Paneel geplaatst.", ephemeral: true });
      },
    },
    {
      data: new SlashCommandBuilder().setName("closeticket").setDescription("Sluit het huidige ticketkanaal."),
      execute: async (interaction) => {
        const ticket = db
          .prepare("SELECT * FROM tickets WHERE guild_id = ? AND channel_id = ? AND status = 'open'")
          .get(interaction.guildId, interaction.channelId) as any;
        if (!ticket) {
          await interaction.reply({ content: "Dit is geen open ticketkanaal.", ephemeral: true });
          return;
        }

        await interaction.reply("🔒 Bezig met sluiten (transcript wordt opgeslagen)...");
        await closeTicket(interaction.channel as TextChannel, interaction.user, ticket);
      },
    },
  ],
};

export default ticketsModule;
