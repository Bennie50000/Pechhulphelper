import { ChatInputCommandInteraction, ButtonInteraction, PermissionFlagsBits, GuildMember } from "discord.js";
import { db } from "./database";
import { STAFF_ROLE_IDS } from "./config";

/**
 * True als het lid:
 * - Discord's eigen "Administrator"-permissie heeft, OF
 * - een rol heeft die in .env staat bij STAFF_ROLE_IDS (vast, geen Discord-rechten nodig
 *   om dit in te stellen — alleen wie toegang heeft tot de serverbestanden), OF
 * - een rol heeft die via /addstaffrole is toegevoegd (opgeslagen in de database)
 */
export function isStaff(interaction: ChatInputCommandInteraction | ButtonInteraction): boolean {
  const member = interaction.member as GuildMember | null;
  if (!member) return false;
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;

  if (STAFF_ROLE_IDS.some((roleId) => member.roles.cache.has(roleId))) return true;

  const staffRoles = db.prepare("SELECT role_id FROM staff_roles WHERE guild_id = ?").all(interaction.guildId) as Array<{ role_id: string }>;
  return staffRoles.some((r) => member.roles.cache.has(r.role_id));
}

/** Checkt staff-rechten en stuurt zelf een foutmelding als het niet mag. Geeft true terug als het command mag doorgaan. */
export async function requireStaff(interaction: ChatInputCommandInteraction): Promise<boolean> {
  if (isStaff(interaction)) return true;
  await interaction.reply({
    content: "❌ Je hebt geen rechten om dit command te gebruiken. Vraag een admin om je rol toe te voegen via `/addstaffrole`.",
    ephemeral: true,
  });
  return false;
}
