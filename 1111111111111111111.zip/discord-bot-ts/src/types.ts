import {
  ChatInputCommandInteraction,
  ButtonInteraction,
  StringSelectMenuInteraction,
  UserSelectMenuInteraction,
  ChannelSelectMenuInteraction,
  ModalSubmitInteraction,
  SlashCommandBuilder,
  SlashCommandOptionsOnlyBuilder,
  SlashCommandSubcommandsOnlyBuilder,
  Client,
  Message,
} from "discord.js";

export type AnySlashCommandBuilder =
  | SlashCommandBuilder
  | SlashCommandOptionsOnlyBuilder
  | SlashCommandSubcommandsOnlyBuilder;

export interface SlashCommand {
  data: AnySlashCommandBuilder;
  execute: (interaction: ChatInputCommandInteraction) => Promise<void>;
}

export interface BotModule {
  name: string;
  commands: SlashCommand[];
  /** Wordt één keer aangeroepen zodra de bot online is (bv. om achtergrondtaken/persistente views te starten). */
  onReady?: (client: Client) => Promise<void> | void;
  /** Optionele handlers voor knoppen/dropdowns/formulieren met een customId die bij deze module hoort. */
  handleButton?: (interaction: ButtonInteraction) => Promise<boolean>;
  handleSelectMenu?: (interaction: StringSelectMenuInteraction) => Promise<boolean>;
  handleUserSelectMenu?: (interaction: UserSelectMenuInteraction) => Promise<boolean>;
  handleChannelSelectMenu?: (interaction: ChannelSelectMenuInteraction) => Promise<boolean>;
  handleModalSubmit?: (interaction: ModalSubmitInteraction) => Promise<boolean>;
  /** Optionele handler voor elk nieuw bericht (bv. voor woordfilters of automatische reacties). */
  handleMessage?: (message: Message) => Promise<void>;
}
